"""Read-only artifact verification and review annotations. Never controls desktop."""
import pathlib,json,datetime,hashlib,urllib.request,zipfile
from PIL import Image
R=pathlib.Path(__file__).resolve().parent
BASE='http://100.105.111.56:18976/'
now=lambda:datetime.datetime.now().astimezone().isoformat()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,d):(R/n).write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
reports=[json.loads(p.read_text(encoding='utf-8')) for p in sorted(R.glob('ui-reference-*-report.json'))]
captures={c['name']:c.copy() for d in reports for c in d['captures']}
rejected={
 'ui-reference-ribbon-format':'Selected tab changed before ribbon contents painted; input tools still visible. Rejected by user and reviewer.',
 'ui-reference-dialog-paragraph':'Dialog HWND/UIA existed, but screenshot preceded first dialog paint; underlying editor captured.',
 'ui-reference-dialog-page':'Dialog HWND/UIA existed, but screenshot preceded first dialog paint; underlying editor captured.',
 'ui-reference-menu-file':'File dropdown was not visible; prior custom WPF menu dismissal consumed click.',
 'ui-reference-dialog-paragraph-rendered':'Valid rendered dialog but own tooltip overlaps selected alignment label. Superseded by clean capture.'}
approved=[n for n in captures if n not in rejected]
def coords(rect,c):
 x,y=c['window_rect'][:2];cx,cy=c['client_origin_screen'];w=c['window_rect'][2]-x;ht=c['window_rect'][3]-y
 return {'screen':rect,'client':[rect[0]-cx,rect[1]-cy,rect[2]-cx,rect[3]-cy],'window_relative':[rect[0]-x,rect[1]-y,rect[2]-x,rect[3]-y],'normalized_window':[round((rect[0]-x)/w,6),round((rect[1]-y)/ht,6),round((rect[2]-x)/w,6),round((rect[3]-y)/ht,6)]}
for n,c in captures.items():
 c['review_status']='rejected_preserved' if n in rejected else 'verified_visual_reference'
 c['review_reason']=rejected.get(n,'Direct review of saved image: actual requested tools/dialog visible, no foreign occlusion.')
 c['reviewed_at']=now();c['raw_url']=BASE+c['raw']
 if c.get('dialog_raw'):c['dialog_url']=BASE+c['dialog_raw']
 c['zoom']={'document_percent':100,'source':'visible status bar; UIA 100% button where available','toolbar_160_percent':'line spacing, not zoom','equation_editor_percent':200 if 'equation' in n else None}
 for e in c.get('uia',{}).get('elements',[]):
  e['coordinates']=coords(e['rect_screen'],c)
  if c['kind']=='dialog':
   dr=c['target']['rect_screen'];rc=e['rect_screen'];e['rect_dialog_relative']=[rc[0]-dr[0],rc[1]-dr[1],rc[2]-dr[0],rc[3]-dr[1]]
 Image.open(R/c['raw']).verify()
 if c.get('dialog_raw'):Image.open(R/c['dialog_raw']).verify()
layout=[]
chrome=captures['ui-reference-ribbon-format-verified']
for name in ['ui-reference-baseline-1327x966','ui-reference-baseline-1916x918']:
 c=captures[name];rc=c['window_rect'];x,y=rc[:2];w=rc[2]-x;ht=rc[3]-y
 assert Image.open(R/c['raw']).size==(w,ht)
 regions={}
 for label,rect in {'title_bar':[1,1,w-1,33],'menu_bar':[1,33,w-1,65],'ribbon':[1,65,w-1,153],'quick_format':[1,153,w-1,185],'document_tabs':[1,ht-55,w-1,ht-26],'status_bar':[1,ht-26,w-1,ht-1]}.items():
  regions[label]={'coordinates':coords([rect[0]+x,rect[1]+y,rect[2]+x,rect[3]+y],c),'method':'UIA measured chrome heights from same 96-DPI dedicated window; dimensions adapted to baseline and visually cross-checked','native_hwnd':None}
 for child in c['native_children']:
  if not child.get('visible'):continue
  cls=child.get('class');rc2=child.get('rect_screen')
  label=None
  if cls=='HwpMainEditWnd':label='body_work_area'
  elif cls=='HwpRulerTabButtonWnd':label='ruler_tab_button'
  elif cls=='HwpRulerWnd':label='horizontal_ruler' if rc2[2]-rc2[0]>rc2[3]-rc2[1] else 'vertical_ruler'
  if label:regions[label]={'coordinates':coords(rc2,c),'method':'GetWindowRect of visible native child','native_hwnd':child['hwnd'],'class':cls,'id':child['id']}
 layout.append({'capture':name,'dpi':c['dpi'],'zoom_percent':100,'window_rect':c['window_rect'],'client_rect':c['client_rect'],'client_origin_screen':c['client_origin_screen'],'regions':regions,'note':'Body native editing area includes gray page surroundings; white paper bounds are separate visual geometry.'})
menus=[]
for en,ko in [('edit','편집'),('view','보기'),('input','입력'),('format','서식'),('page','쪽'),('security','보안'),('review','검토'),('tools','도구')]:
 c=captures['ui-reference-ribbon-'+en+'-label'];arrow=captures['ui-reference-menu-'+en+'-arrow']
 if en=='page':c=captures['ui-reference-ribbon-page-complete']
 items=c.get('uia',{}).get('elements',[])
 item=next(e for e in items if e['control_type']=='MenuItem' and e['name'].startswith(ko+' '))
 buttons=[e for e in items if e['visible'] and e['control_type'] in ['Button','MenuItem','ComboBox','CheckBox','RadioButton'] and 65<=e['coordinates']['window_relative'][1]<153]
 assert buttons,'ribbon UIA metadata incomplete: '+en
 clicks=[e for d in reports for e in d['events'] if e['kind']=='click' and e.get('label') in [en+' label',en+' arrow']]
 menus.append({'menu':ko,'english_key':en,'menu_item_uia_bounds':item['coordinates'],'label_behavior':'switch ribbon tools; no dropdown','arrow_behavior':'open command dropdown over editor; ribbon remains current','label_capture':c['name'],'arrow_capture':arrow['name'],'tested_clicks':clicks,'ribbon_controls':buttons,'dropdown_controls':arrow.get('uia',{}).get('elements',[]),'subregions_note':'UIA exposes full menu item bounds. Label/arrow distinction proven at logged points; glyph subregions are not separate native HWNDs.'})
defaults={
 'font':{'base_size':'10.0 pt','language':'대표','font':'함초롬바탕','relative_size':'100%','width':'100%','position':'0%','letter_spacing':'0%','text_color':'black'},
 'paragraph':{'alignment':'양쪽 정렬','left':'0.0 pt','right':'0.0 pt','first_line':'보통','line_spacing_kind':'글자에 따라','line_spacing':'160%','before':'0.0 pt','after':'0.0 pt','use_page_grid':True,'korean_wrap':'글자','english_wrap':'단어','minimum_space':'100%'},
 'page':{'paper':'A4(국배판) [210 x 297 mm]','width':'210.0 mm','height':'297.0 mm','orientation':'세로','binding':'한쪽','top':'20.0 mm','header':'15.0 mm','left':'30.0 mm','right':'30.0 mm','binding_margin':'0.0 mm','footer':'15.0 mm','bottom':'15.0 mm','apply_to':'문서 전체'},
 'table':{'rows':1,'columns':1,'width_mode':'임의 값','width':'148.0 mm','height_mode':'자동','disabled_height':'22.6 mm','treat_as_character':False,'create_with_mouse':False},
 'equation':{'font':'HYhwpEQ','font_size':'11','zoom':'200%','command_autocomplete':True,'expression':'empty'}}
dialog_names={'font':'ui-reference-dialog-font-recovered','paragraph':'ui-reference-dialog-paragraph-clean','page':'ui-reference-dialog-page-rendered','table':'ui-reference-dialog-table','equation':'ui-reference-dialog-equation'}
dialogs=[]
for label,name in dialog_names.items():
 c=captures[name];assert name in approved
 dialogs.append({'dialog':label,'capture':name,'title':c['target']['name'],'rect_screen':c['target']['rect_screen'],'native_window':c['target'],'default_values':defaults[label],'default_values_source':'visual inspection of rendered dialog, corroborated by UIA accessible names where available','controls':c['uia']['elements'],'native_children':c['native_children'],'shortcut':{'font':'Alt+L','paragraph':'Alt+T','page':'F7','table':'Ctrl+N then T','equation':'Ctrl+N then M'}[label]})
 if label=='equation':
  dialogs[-1]['uia_limitation']='Bounded UIA scan returned no elements before read deadline. Native HWP_EqMainView HWND/rect retained; image-derived regions below are not individually tested control hit areas.'
  dr=c['target']['rect_screen']
  regions={'title_bar':[0,0,950,32],'toolbars':[1,32,949,98],'formula_preview':[1,99,949,274],'script_input':[1,277,949,375],'font_dropdown':[558,69,652,93],'size_dropdown':[661,69,751,93],'zoom_dropdown':[798,69,888,93],'autocomplete_checkbox':[744,339,860,371]}
  dialogs[-1]['visual_regions']=[{'name':key,'rect_dialog_relative':rect,'coordinates':coords([dr[0]+rect[0],dr[1]+rect[1],dr[0]+rect[2],dr[1]+rect[3]],c),'method':'visible pixel boundary; approximately 1-2 px tolerance; not native control bounds'} for key,rect in regions.items()]
handoffs=[]
for d in reports:
 assert d['inputs_finished'] and d.get('request_deleted_at')
 if d.get('acquired_at'):
  start=datetime.datetime.fromisoformat(d['acquired_at']);end=datetime.datetime.fromisoformat(d['input_finished_at']);duration=(end-start).total_seconds();assert duration<60
  assert d['input_finished_at']<=d['released_at']<=d['request_deleted_at']
  assert d.get('astris_reacquired_at')
  handoffs.append({'phase':d['phase'],'status':d.get('status'),'error':d.get('error'),'input_seconds':duration,**{key:d.get(key) for key in ['request_created_at','acquired_at','input_finished_at','released_at','request_deleted_at','astris_reacquired_at','cleanup_verified','cleanup_error','source_sha256','collector_sha256']}})
preserved=[]
for old in json.loads((R/'retry2-artifact-index.json').read_text(encoding='utf-8')):
 f=pathlib.Path(old['path']);assert sha(f)==old['sha256'],str(f);preserved.append({'name':f.name,'sha256':old['sha256']})
manifest={'schema':'actual-hwp-ui-reference-v1','status':'verified_actual_ui_reference','verified_at':now(),'output_directory':str(R),'source_scope':'Native HWP measurement/capture only. No web app implementation or UI completion claim. Prior button-four-state capture does not establish full UI parity.','target_hwnd':985892,'target_pid':4032,'coordinate_convention':'Physical pixels, 96 DPI; rects [left,top,right,bottom) in screen/client/window-relative/normalized spaces. Native HWNDs and UIA elements distinguished.','baseline_layouts':layout,'menus':menus,'file_menu_capture':'ui-reference-menu-file-open','dialogs':dialogs,'captures':[captures[n] for n in sorted(captures)],'rejected_captures':rejected,'handoffs':handoffs,'prior_artifact_hashes_verified':preserved,'manual_user_action':'none','remaining_scope':'None for requested UI reference set; web rebuild and behavioral implementation are outside measurement role.','reproduction':['Collector phase priority obtains two sizes/input/format and attempts first dialogs; historical failed evidence retained.','Subsequent phases recover owned WPF dialog, wait for rendering, read UIA before pixels, then capture menus/dialogs in bounded requests.','Commands: python -B ui-reference-collector.py <phase>; existing phase reports/captures refuse overwrite. Fresh evidence paths and coordinated request/OS lock required.'],'limitations':['WPF ribbon/dialog controls often have no individual native HWND or numeric ID; UIA class/automation_id/bounds supplied instead.','Original priority and first recovery reports retain failures and stale-render evidence; only approved captures are reconstruction references.','Popup/foreground appearance alone is insufficient render readiness; accepted images were opened and tools/dialog contents reviewed.'],'server_base':BASE}
save('ui-reference-manifest.json',manifest)
index=[{'path':str(p),'url':BASE+p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(R.glob('ui-reference-*')) if p.is_file() and p.suffix not in ['.zip'] and p.name!='ui-reference-artifact-index.json']
save('ui-reference-artifact-index.json',index)
with zipfile.ZipFile(R/'ui-reference-verified-artifacts.zip','w',zipfile.ZIP_DEFLATED) as z:
 for item in index:z.write(item['path'],pathlib.Path(item['path']).name)
 z.write(R/'ui-reference-artifact-index.json','ui-reference-artifact-index.json')
for name in ['ui-reference-manifest.json','ui-reference-verified-artifacts.zip']:
 with urllib.request.urlopen(BASE+name,timeout=15) as f:assert hashlib.sha256(f.read()).hexdigest()==sha(R/name)
print(json.dumps({'status':manifest['status'],'manifest':str(R/'ui-reference-manifest.json'),'approved_captures':len(approved),'rejected_preserved':len(rejected),'menus':len(menus),'dialogs':len(dialogs),'baseline_sizes':[[1327,966],[1916,918]],'bundle_url':BASE+'ui-reference-verified-artifacts.zip','bundle_sha256':sha(R/'ui-reference-verified-artifacts.zip'),'remote_content_hash_verified':True,'prior_artifacts_unchanged':True},indent=2))
