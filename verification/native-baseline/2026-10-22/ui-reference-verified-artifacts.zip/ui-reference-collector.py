"""Bounded synchronous UI reference collection; no COM, app edits or resident commands."""
import pathlib,sys,os,time,json,datetime,hashlib,importlib.util,ctypes as C
import ctypes.wintypes as W
import win32gui as g,win32api as a,win32process as p,win32con as k
from PIL import ImageGrab
R=pathlib.Path(__file__).resolve().parent
PHASE=sys.argv[1]
assert PHASE in ['priority','priority-fix','priority-recovery','dialog-verification','menus','menus-a','menus-b','menus-c','file','file-final','dialogs','page-controls']
OUT=R/f'ui-reference-{PHASE}-report.json'
assert not OUT.exists(),'Evidence exists; refusing overwrite'
S=pathlib.Path(r'C:\Users\K\.orca\coordination\desktop_control.py')
assert not os.environ.get('DESKTOP_CONTROL_DIR')
spec=importlib.util.spec_from_file_location('shared_desktop_control',S)
dc=importlib.util.module_from_spec(spec);spec.loader.exec_module(dc)
u=C.windll.user32;u.SetProcessDpiAwarenessContext(C.c_void_p(-4))
h=985892;pid=4032;token=req=None;deadline=0;down=False;keys=set();opened=None
now=lambda:datetime.datetime.now().astimezone().isoformat()
d={'phase':PHASE,'started':now(),'pid':os.getpid(),'target_hwnd':h,'target_pid':pid,'source':str(S),'source_sha256':hashlib.sha256(S.read_bytes()).hexdigest(),'collector':str(pathlib.Path(__file__).resolve()),'collector_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'events':[],'captures':[],'inputs_finished':False,'com_used':False,'resident_commands_sent':False}
def save():
 tmp=OUT.with_suffix('.tmp');tmp.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(tmp,OUT)
def event(kind,**kw):d['events'].append({'kind':kind,'time':now(),'epoch':time.time(),**kw});save()
def related(w):
 try:
  if not w or p.GetWindowThreadProcessId(w)[1]!=pid:return False
  root=g.GetAncestor(w,2)
  for _ in range(8):
   if root==h:return True
   root=g.GetWindow(root,k.GW_OWNER)
   if not root:break
  return False
 except:return False
def check(cleanup=False):
 assert token and dc.holds(token) and dc.current_owner().get('token')==token,'OS lock ownership lost'
 assert time.time()<(d['request_deadline']-5 if cleanup else deadline),'input deadline'
 assert related(g.GetForegroundWindow()),'foreign foreground; no input'
def info(w):
 rc=g.GetWindowRect(w);o=g.ClientToScreen(h,(0,0));wr=g.GetWindowRect(h)
 return {'hwnd':w,'pid':p.GetWindowThreadProcessId(w)[1],'class':g.GetClassName(w),'name':g.GetWindowText(w),'id':g.GetDlgCtrlID(w),'rect_screen':rc,'rect_client_main':[rc[0]-o[0],rc[1]-o[1],rc[2]-o[0],rc[3]-o[1]],'rect_window_main':[rc[0]-wr[0],rc[1]-wr[1],rc[2]-wr[0],rc[3]-wr[1]],'visible':bool(g.IsWindowVisible(w)),'enabled':bool(g.IsWindowEnabled(w)),'parent':g.GetParent(w),'owner':g.GetWindow(g.GetAncestor(w,2),k.GW_OWNER),'root_owner':g.GetAncestor(w,3)}
def uia_read(w):
 out=[];until=min(time.time()+4,deadline-3)
 try:
  from pywinauto import Desktop
  queue=[(Desktop(backend='uia').window(handle=w).wrapper_object().element_info,0)]
  while queue and len(out)<450 and time.time()<until:
   e,depth=queue.pop(0);rc=e.rectangle
   out.append({'name':e.name,'class':e.class_name,'automation_id':e.automation_id,'control_type':e.control_type,'hwnd':e.handle,'rect_screen':[rc.left,rc.top,rc.right,rc.bottom],'visible':e.visible,'enabled':e.enabled})
   if depth<7:queue.extend((child,depth+1) for child in e.children())
  return {'elements':out,'truncated':bool(queue),'method':'UIA read-only; native dialog editing COM not used'}
 except Exception as e:return {'elements':out,'error':repr(e)}
def children(w):
 out=[]
 def cb(c,_):
  try:out.append(info(c))
  except Exception as e:out.append({'hwnd':c,'error':repr(e)})
 g.EnumChildWindows(w,cb,None);return out
class GTI(C.Structure):
 _fields_=[('size',W.DWORD),('flags',W.DWORD),('active',W.HWND),('focus',W.HWND),('capture',W.HWND),('menu',W.HWND),('move',W.HWND),('caret',W.HWND),('rect',W.RECT)]
def gui():
 t=GTI();t.size=C.sizeof(t);thread=p.GetWindowThreadProcessId(h)[0]
 assert u.GetGUIThreadInfo(thread,C.byref(t))
 return {'flags':t.flags,'active':t.active,'focus':t.focus,'menu_owner':t.menu,'capture':t.capture}
def snap(label,kind='editor',target=None):
 check();target=target or h;assert related(target)
 accessibility=uia_read(target)
 if kind=='dialog':
  time.sleep(.9);check()
  rc=g.GetWindowRect(target);pt=(rc[0]+min(220,(rc[2]-rc[0])//2),rc[1]+14)
  assert g.GetAncestor(g.WindowFromPoint(pt),2)==target,'rendered dialog title not hit; no mouse input'
  a.SetCursorPos(pt);a.mouse_event(k.MOUSEEVENTF_MOVE,1,0,0,0);a.mouse_event(k.MOUSEEVENTF_MOVE,-1,0,0,0)
  event('move_to_owned_dialog_title',screen=pt,hwnd=target)
 if kind=='dialog':time.sleep(.9)
 check()
 name='ui-reference-'+label;assert not (R/(name+'.raw.png')).exists()
 fg=g.GetForegroundWindow();rect=g.GetWindowRect(h);tr=g.GetWindowRect(target)
 shot=ImageGrab.grab(bbox=rect,all_screens=True);shot.save(R/(name+'.raw.png'))
 if target!=h:ImageGrab.grab(bbox=tr,all_screens=True).save(R/(name+'.dialog.png'))
 samples=[]
 for x in [rect[0]+20,(rect[0]+rect[2])//2,rect[2]-20]:
  for y in [rect[1]+15,rect[1]+100,(rect[1]+rect[3])//2,rect[3]-15]:
   w=g.WindowFromPoint((x,y));samples.append({'screen':[x,y],'hwnd':w,'related':related(g.GetAncestor(w,2))})
 assert related(g.GetForegroundWindow()) and all(v['related'] for v in samples),'occlusion or foreground changed'
 c={'name':name,'kind':kind,'time':now(),'raw':name+'.raw.png','dialog_raw':name+'.dialog.png' if target!=h else None,'window':info(h),'window_rect':rect,'client_rect':g.GetClientRect(h),'client_origin_screen':g.ClientToScreen(h,(0,0)),'dpi':u.GetDpiForWindow(h),'units':'physical pixels; rectangles half-open','zoom':{'text':'100%','source':'status bar visual review required','ribbon_160_percent':'character width ratio; not document zoom'},'foreground':info(fg),'target':info(target),'gui_thread':gui(),'native_children':children(target),'main_native_children':children(h) if target!=h else None,'occlusion_samples':samples,'input_event_count':len(d['events']),'status':'pending_visual_review'}
 c['uia']=accessibility
 d['captures'].append(c);save();print(json.dumps({'capture':str(R/c['raw']),'report':str(OUT)},ensure_ascii=True),flush=True)
 return c
def click(x,y,label):
 global down
 check();assert g.GetForegroundWindow()==h,'main editor not foreground'
 pt=g.ClientToScreen(h,(x,y));hit=g.WindowFromPoint(pt);assert related(g.GetAncestor(hit,2))
 a.SetCursorPos(pt);a.mouse_event(k.MOUSEEVENTF_MOVE,1,0,0,0);a.mouse_event(k.MOUSEEVENTF_MOVE,-1,0,0,0)
 check();assert related(g.GetAncestor(g.WindowFromPoint(pt),2))
 a.mouse_event(k.MOUSEEVENTF_LEFTDOWN,0,0);down=True
 try:pass
 finally:a.mouse_event(k.MOUSEEVENTF_LEFTUP,0,0);down=False
 wr=g.GetWindowRect(h);event('click',label=label,client=[x,y],screen=pt,window_relative=[pt[0]-wr[0],pt[1]-wr[1]],hit=info(hit));time.sleep(.8)
def chord(vks,label,cleanup=False):
 check(cleanup)
 try:
  for vk in vks:a.keybd_event(vk,0,0,0);keys.add(vk)
 finally:
  for vk in reversed(vks):a.keybd_event(vk,0,k.KEYEVENTF_KEYUP,0);keys.discard(vk)
 event('key_chord',keys=vks,label=label,foreground=g.GetForegroundWindow());time.sleep(.3)
def escape_owned():
 global opened
 check(True);fg=g.GetForegroundWindow();state=gui()
 assert related(fg)
 if fg!=h:assert opened==fg,'unexpected dialog; no Escape'
 elif state['flags']&28:assert state['menu_owner'] and related(state['menu_owner']),'unproven menu owner'
 elif state['capture']==h and state['focus']==h:event('own_wpf_menu_capture_verified',state=state)
 else:return
 chord([k.VK_ESCAPE],'close own dialog/menu',True)
 until=time.time()+3
 while time.time()<until and (g.GetForegroundWindow()!=h or gui()['flags']&28):time.sleep(.1)
 assert g.GetForegroundWindow()==h and not(gui()['flags']&28) and not gui()['capture'],'own dialog/menu did not close'
 opened=None
def resize(w,ht):
 check();assert g.GetForegroundWindow()==h
 g.SetWindowPos(h,k.HWND_TOP,2,40,w,ht,k.SWP_SHOWWINDOW);event('resize',width=w,height=ht);time.sleep(.3)
 assert tuple(g.GetWindowRect(h)[2+i]-g.GetWindowRect(h)[i] for i in [0,1])==(w,ht)
def activate():
 assert dc.holds(token) and time.time()<deadline
 existing=[]
 def cb(w,_):
  if w!=h and g.IsWindowVisible(w) and related(w):existing.append(w)
 g.EnumWindows(cb,None)
 if existing:
  assert len(existing)==1 and not g.IsWindowEnabled(h),'unexpected pre-existing owned windows'
  global opened
  opened=existing[0]
  g.SetWindowPos(opened,k.HWND_TOP,0,0,0,0,k.SWP_NOMOVE|k.SWP_NOSIZE|k.SWP_SHOWWINDOW)
  u.SetForegroundWindow(opened);time.sleep(.3)
  if g.GetForegroundWindow()!=opened:
   rc=g.GetWindowRect(opened);pt=((rc[0]+rc[2])//2,rc[1]+14)
   assert g.GetAncestor(g.WindowFromPoint(pt),2)==opened and related(opened) and dc.holds(token) and time.time()<deadline
   a.SetCursorPos(pt);a.mouse_event(k.MOUSEEVENTF_LEFTDOWN,0,0)
   try:pass
   finally:a.mouse_event(k.MOUSEEVENTF_LEFTUP,0,0)
   event('activate_owned_dialog_title',hwnd=opened,screen=pt);time.sleep(.4)
  snap('dialog-font-recovered','dialog',opened);escape_owned()
 g.SetWindowPos(h,k.HWND_TOP,2,40,1327,966,k.SWP_SHOWWINDOW);u.SetForegroundWindow(h);time.sleep(.15)
 if g.GetForegroundWindow()!=h:
  rc=g.GetWindowRect(h);pt=((rc[0]+rc[2])//2,rc[1]+12)
  assert g.GetAncestor(g.WindowFromPoint(pt),2)==h
  a.SetCursorPos(pt);a.mouse_event(k.MOUSEEVENTF_LEFTDOWN,0,0)
  try:pass
  finally:a.mouse_event(k.MOUSEEVENTF_LEFTUP,0,0)
  event('activate_title_click',screen=pt);time.sleep(.2)
 assert g.GetForegroundWindow()==h
def dialog(label,seq):
 global opened
 check();assert g.GetForegroundWindow()==h and not(gui()['flags']&28)
 for keys_,text in seq:chord(keys_,text)
 until=min(time.time()+4,deadline-3)
 while time.time()<until:
  fg=g.GetForegroundWindow()
  if fg!=h and related(fg):break
  time.sleep(.1)
 fg=g.GetForegroundWindow()
 assert fg!=h and related(fg),'expected owned dialog not found'
 opened=fg;snap(label,'dialog',fg);escape_owned()
try:
 assert g.IsWindow(h) and p.GetWindowThreadProcessId(h)[1]==pid
 assert not (R/'command.json').exists()
 event('before_request',owner=dc.current_owner(),pending=dc.pending_request(),target=info(h))
 req=dc.request('Web HWP','ui-reference-2026-10-22',PHASE+' UI reference capture',120)
 assert req,'foreign request pending; no overwrite'
 rr=dc.pending_request();assert rr['token']==req
 d.update(request_token=req,request_created_at=now(),request_deadline=rr['requested_at']+120);save()
 token=dc.acquire('Web HWP','ui-reference-2026-10-22',PHASE,timeout=40,request_token=req)
 deadline=min(time.time()+50,d['request_deadline']-10)
 d.update(lock_token=token,acquired_at=now(),input_deadline_epoch=deadline)
 event('acquired',owner=dc.current_owner(),heartbeat=dc.heartbeat(token))
 activate();escape_owned()
 if PHASE=='priority':
  snap('baseline-1327x966')
  resize(1916,918);snap('baseline-1916x918');resize(1327,966)
  click(216,48,'입력 label');snap('ribbon-input')
  click(276,48,'서식 label');snap('ribbon-format')
  click(96,48,'편집 label')
  dialog('dialog-font', [([k.VK_MENU,ord('L')],'Alt+L')])
  dialog('dialog-paragraph',[([k.VK_MENU,ord('T')],'Alt+T')])
  dialog('dialog-page',[([k.VK_F7],'F7')])
 elif PHASE in ['priority-fix','priority-recovery']:
  click(276,48,'서식 label');snap('ribbon-format-verified')
  click(96,48,'편집 label');click(500,400,'focus blank document body')
  dialog('dialog-paragraph',[([k.VK_MENU,ord('T')],'Alt+T')])
  dialog('dialog-page',[([k.VK_F7],'F7')])
 elif PHASE=='dialog-verification':
  click(96,48,'편집 label');click(500,400,'focus blank document body')
  dialog('dialog-paragraph-rendered',[([k.VK_MENU,ord('T')],'Alt+T')])
  dialog('dialog-page-rendered',[([k.VK_F7],'F7')])
 elif PHASE.startswith('menus'):
  entries=[('edit',96,119),('view',156,179),('input',216,239),('format',276,299),('page',330,350),('security',388,410),('review',446,468),('tools',504,527)]
  if PHASE=='menus-a':entries=[entries[i] for i in [0,2,3]]
  if PHASE=='menus-b':entries=[entries[i] for i in [1,4,5]]
  if PHASE=='menus-c':entries=[entries[i] for i in [6,7]]
  for label,x,arrow in entries:
   click(x,48,label+' label');snap('ribbon-'+label+'-label')
   click(arrow,48,label+' arrow');snap('menu-'+label+'-arrow','dropdown');escape_owned()
  if PHASE in ['menus','menus-a']:click(32,48,'파일 label');snap('menu-file','file-menu');escape_owned()
 elif PHASE=='dialogs':
  click(96,48,'편집 label')
  dialog('dialog-table',[([k.VK_CONTROL,ord('N')],'Ctrl+N prefix'),([ord('T')],'T')])
  dialog('dialog-equation',[([k.VK_CONTROL,ord('N')],'Ctrl+N prefix'),([ord('M')],'M')])
 elif PHASE in ['file','file-final']:
  click(500,400,'focus blank document body')
  dialog('dialog-paragraph-clean',[([k.VK_MENU,ord('T')],'Alt+T')])
  click(32,48,'파일 label');time.sleep(.8);snap('menu-file-open','file-menu');escape_owned()
 elif PHASE=='page-controls':
  click(330,48,'쪽 label for complete UIA');time.sleep(1.6);snap('ribbon-page-complete')
 d['status']='captured_pending_review'
except Exception as e:d['status']='failed_preserved';d['error']=repr(e);event('failure',error=repr(e))
finally:
 if token:
  if down:a.mouse_event(k.MOUSEEVENTF_LEFTUP,0,0);down=False
  for vk in list(keys):a.keybd_event(vk,0,k.KEYEVENTF_KEYUP,0);keys.discard(vk)
  try:escape_owned();d['cleanup_verified']=True
  except Exception as e:d['cleanup_verified']=False;d['cleanup_error']=repr(e)
  d.update(inputs_finished=True,input_finished_at=now(),down_remaining=down,keys_remaining=list(keys));save()
  assert dc.release(token);d['released_at']=now();event('release_completed')
 if req:
  own=dc.pending_request();assert own and own.get('token')==req
  assert dc.cancel_request(req);d['request_deleted_at']=now();event('own_request_deleted')
 if token:
  until=time.time()+10
  while time.time()<until:
   owner=dc.current_owner();d['owner_after_return']=owner
   if owner and owner.get('owner')=='Astris':d['astris_reacquired_at']=now();break
   time.sleep(.5)
 d['finished']=now();save();print(json.dumps({'status':d['status'],'captures':len(d['captures']),'error':d.get('error'),'report':str(OUT),'owner_after_return':d.get('owner_after_return')},ensure_ascii=True),flush=True)
