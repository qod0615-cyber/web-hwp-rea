"""Bounded synchronous UI reference collection; no COM, app edits or resident commands."""
import pathlib,sys,os,time,json,datetime,hashlib,importlib.util,ctypes as C
import ctypes.wintypes as W
import win32gui as g,win32api as a,win32process as p,win32con as k
from PIL import ImageGrab
R=pathlib.Path(__file__).resolve().parent
PHASE='zoom-110'

OUT=R/'behavior-reference-zoom-report.json'
assert not OUT.exists(),'Evidence exists; refusing overwrite'
S=pathlib.Path(r'C:\Users\K\.orca\coordination\desktop_control.py')
assert not os.environ.get('DESKTOP_CONTROL_DIR')
spec=importlib.util.spec_from_file_location('shared_desktop_control',S)
dc=importlib.util.module_from_spec(spec);spec.loader.exec_module(dc)
u=C.windll.user32;u.SetProcessDpiAwarenessContext(C.c_void_p(-4))
h=985892;pid=4032;token=req=None;deadline=0;down=False;keys=set();opened=None
now=lambda:datetime.datetime.now().astimezone().isoformat()
d={'phase':PHASE,'started':now(),'pid':os.getpid(),'target_hwnd':h,'target_pid':pid,'source':str(S),'source_sha256':hashlib.sha256(S.read_bytes()).hexdigest(),'collector':str(pathlib.Path(__file__).resolve()),'collector_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'events':[],'captures':[],'inputs_finished':False,'com_used':False,'resident_commands_sent':False}
def save():
 tmp=OUT.with_suffix('.tmp');tmp.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(tmp,OUT)
def event(kind,**kw):d['events'].append({'kind':kind,'time':now(),'epoch':time.time(),**kw});save()
def related(w):
 try:
  if not w or p.GetWindowThreadProcessId(w)[1]!=pid:return False
  root=g.GetAncestor(w,2)
  for _ in range(8):
   if root==h:return True
   root=g.GetWindow(root,k.GW_OWNER)
   if not root:break
  return False
 except:return False
def check(cleanup=False):
 assert token and dc.holds(token) and dc.current_owner().get('token')==token,'OS lock ownership lost'
 assert time.time()<(d['request_deadline']-5 if cleanup else deadline),'input deadline'
 assert related(g.GetForegroundWindow()),'foreign foreground; no input'
def info(w):
 rc=g.GetWindowRect(w);o=g.ClientToScreen(h,(0,0));wr=g.GetWindowRect(h)
 return {'hwnd':w,'pid':p.GetWindowThreadProcessId(w)[1],'class':g.GetClassName(w),'name':g.GetWindowText(w),'id':g.GetDlgCtrlID(w),'rect_screen':rc,'rect_client_main':[rc[0]-o[0],rc[1]-o[1],rc[2]-o[0],rc[3]-o[1]],'rect_window_main':[rc[0]-wr[0],rc[1]-wr[1],rc[2]-wr[0],rc[3]-wr[1]],'visible':bool(g.IsWindowVisible(w)),'enabled':bool(g.IsWindowEnabled(w)),'parent':g.GetParent(w),'owner':g.GetWindow(g.GetAncestor(w,2),k.GW_OWNER),'root_owner':g.GetAncestor(w,3)}
def uia_read(w):
 out=[];until=min(time.time()+4,deadline-3)
 try:
  from pywinauto import Desktop
  queue=[(Desktop(backend='uia').window(handle=w).wrapper_object().element_info,0)]
  while queue and len(out)<450 and time.time()<until:
   e,depth=queue.pop(0);rc=e.rectangle
   out.append({'name':e.name,'class':e.class_name,'automation_id':e.automation_id,'control_type':e.control_type,'hwnd':e.handle,'rect_screen':[rc.left,rc.top,rc.right,rc.bottom],'visible':e.visible,'enabled':e.enabled})
   if depth<7:queue.extend((child,depth+1) for child in e.children())
  return {'elements':out,'truncated':bool(queue),'method':'UIA read-only; native dialog editing COM not used'}
 except Exception as e:return {'elements':out,'error':repr(e)}
def children(w):
 out=[]
 def cb(c,_):
  try:out.append(info(c))
  except Exception as e:out.append({'hwnd':c,'error':repr(e)})
 g.EnumChildWindows(w,cb,None);return out
class GTI(C.Structure):
 _fields_=[('size',W.DWORD),('flags',W.DWORD),('active',W.HWND),('focus',W.HWND),('capture',W.HWND),('menu',W.HWND),('move',W.HWND),('caret',W.HWND),('rect',W.RECT)]
def gui():
 t=GTI();t.size=C.sizeof(t);thread=p.GetWindowThreadProcessId(h)[0]
 assert u.GetGUIThreadInfo(thread,C.byref(t))
 return {'flags':t.flags,'active':t.active,'focus':t.focus,'menu_owner':t.menu,'capture':t.capture}
def snap(label,kind='editor',target=None):
 check();target=target or h;assert related(target)
 accessibility=uia_read(target)
 if kind=='dialog':
  time.sleep(.9);check()
  rc=g.GetWindowRect(target);pt=(rc[0]+min(220,(rc[2]-rc[0])//2),rc[1]+14)
  assert g.GetAncestor(g.WindowFromPoint(pt),2)==target,'rendered dialog title not hit; no mouse input'
  a.SetCursorPos(pt);a.mouse_event(k.MOUSEEVENTF_MOVE,1,0,0,0);a.mouse_event(k.MOUSEEVENTF_MOVE,-1,0,0,0)
  event('move_to_owned_dialog_title',screen=pt,hwnd=target)
 if kind=='dialog':time.sleep(.9)
 check()
 name='behavior-reference-'+label;assert not (R/(name+'.raw.png')).exists()
 fg=g.GetForegroundWindow();rect=g.GetWindowRect(h);tr=g.GetWindowRect(target)
 shot=ImageGrab.grab(bbox=rect,all_screens=True);shot.save(R/(name+'.raw.png'))
 if target!=h:ImageGrab.grab(bbox=tr,all_screens=True).save(R/(name+'.dialog.png'))
 samples=[]
 for x in [rect[0]+20,(rect[0]+rect[2])//2,rect[2]-20]:
  for y in [rect[1]+15,rect[1]+100,(rect[1]+rect[3])//2,rect[3]-15]:
   w=g.WindowFromPoint((x,y));samples.append({'screen':[x,y],'hwnd':w,'related':related(g.GetAncestor(w,2))})
 assert related(g.GetForegroundWindow()) and all(v['related'] for v in samples),'occlusion or foreground changed'
 c={'name':name,'kind':kind,'time':now(),'raw':name+'.raw.png','dialog_raw':name+'.dialog.png' if target!=h else None,'window':info(h),'window_rect':rect,'client_rect':g.GetClientRect(h),'client_origin_screen':g.ClientToScreen(h,(0,0)),'dpi':u.GetDpiForWindow(h),'units':'physical pixels; rectangles half-open','zoom':{'text':'100%','source':'status bar visual review required','ribbon_160_percent':'character width ratio; not document zoom'},'foreground':info(fg),'target':info(target),'gui_thread':gui(),'native_children':children(target),'main_native_children':children(h) if target!=h else None,'occlusion_samples':samples,'input_event_count':len(d['events']),'status':'pending_visual_review'}
 c['uia']=accessibility
 d['captures'].append(c);save();print(json.dumps({'capture':str(R/c['raw']),'report':str(OUT)},ensure_ascii=True),flush=True)
 return c
def click(x,y,label):
 global down
 check();assert g.GetForegroundWindow()==h,'main editor not foreground'
 pt=g.ClientToScreen(h,(x,y));hit=g.WindowFromPoint(pt);assert related(g.GetAncestor(hit,2))
 a.SetCursorPos(pt);a.mouse_event(k.MOUSEEVENTF_MOVE,1,0,0,0);a.mouse_event(k.MOUSEEVENTF_MOVE,-1,0,0,0)
 check();assert related(g.GetAncestor(g.WindowFromPoint(pt),2))
 a.mouse_event(k.MOUSEEVENTF_LEFTDOWN,0,0);down=True
 try:pass
 finally:a.mouse_event(k.MOUSEEVENTF_LEFTUP,0,0);down=False
 wr=g.GetWindowRect(h);event('click',label=label,client=[x,y],screen=pt,window_relative=[pt[0]-wr[0],pt[1]-wr[1]],hit=info(hit));time.sleep(.8)
def chord(vks,label,cleanup=False):
 check(cleanup)
 try:
  for vk in vks:a.keybd_event(vk,0,0,0);keys.add(vk)
 finally:
  for vk in reversed(vks):a.keybd_event(vk,0,k.KEYEVENTF_KEYUP,0);keys.discard(vk)
 event('key_chord',keys=vks,label=label,foreground=g.GetForegroundWindow());time.sleep(.3)
def escape_owned():
 global opened
 check(True);fg=g.GetForegroundWindow();state=gui()
 assert related(fg)
 if fg!=h:assert opened==fg,'unexpected dialog; no Escape'
 elif state['flags']&28:assert state['menu_owner'] and related(state['menu_owner']),'unproven menu owner'
 elif state['capture']==h and state['focus']==h:event('own_wpf_menu_capture_verified',state=state)
 else:return
 chord([k.VK_ESCAPE],'close own dialog/menu',True)
 until=time.time()+3
 while time.time()<until and (g.GetForegroundWindow()!=h or gui()['flags']&28):time.sleep(.1)
 assert g.GetForegroundWindow()==h and not(gui()['flags']&28) and not gui()['capture'],'own dialog/menu did not close'
 opened=None
def resize(w,ht):
 check();assert g.GetForegroundWindow()==h
 g.SetWindowPos(h,k.HWND_TOP,2,40,w,ht,k.SWP_SHOWWINDOW);event('resize',width=w,height=ht);time.sleep(.3)
 assert tuple(g.GetWindowRect(h)[2+i]-g.GetWindowRect(h)[i] for i in [0,1])==(w,ht)
def activate():
 assert dc.holds(token) and time.time()<deadline
 existing=[]
 def cb(w,_):
  if w!=h and g.IsWindowVisible(w) and related(w):existing.append(w)
 g.EnumWindows(cb,None)
 if existing:
  assert len(existing)==1 and not g.IsWindowEnabled(h),'unexpected pre-existing owned windows'
  global opened
  opened=existing[0]
  g.SetWindowPos(opened,k.HWND_TOP,0,0,0,0,k.SWP_NOMOVE|k.SWP_NOSIZE|k.SWP_SHOWWINDOW)
  u.SetForegroundWindow(opened);time.sleep(.3)
  if g.GetForegroundWindow()!=opened:
   rc=g.GetWindowRect(opened);pt=((rc[0]+rc[2])//2,rc[1]+14)
   assert g.GetAncestor(g.WindowFromPoint(pt),2)==opened and related(opened) and dc.holds(token) and time.time()<deadline
   a.SetCursorPos(pt);a.mouse_event(k.MOUSEEVENTF_LEFTDOWN,0,0)
   try:pass
   finally:a.mouse_event(k.MOUSEEVENTF_LEFTUP,0,0)
   event('activate_owned_dialog_title',hwnd=opened,screen=pt);time.sleep(.4)
  snap('dialog-font-recovered','dialog',opened);escape_owned()
 g.SetWindowPos(h,k.HWND_TOP,2,40,1327,966,k.SWP_SHOWWINDOW);u.SetForegroundWindow(h);time.sleep(.15)
 if g.GetForegroundWindow()!=h:
  rc=g.GetWindowRect(h);pt=((rc[0]+rc[2])//2,rc[1]+12)
  assert g.GetAncestor(g.WindowFromPoint(pt),2)==h
  a.SetCursorPos(pt);a.mouse_event(k.MOUSEEVENTF_LEFTDOWN,0,0)
  try:pass
  finally:a.mouse_event(k.MOUSEEVENTF_LEFTUP,0,0)
  event('activate_title_click',screen=pt);time.sleep(.2)
 assert g.GetForegroundWindow()==h
def dialog(label,seq):
 global opened
 check();assert g.GetForegroundWindow()==h and not(gui()['flags']&28)
 for keys_,text in seq:chord(keys_,text)
 until=min(time.time()+4,deadline-3)
 while time.time()<until:
  fg=g.GetForegroundWindow()
  if fg!=h and related(fg):break
  time.sleep(.1)
 fg=g.GetForegroundWindow()
 assert fg!=h and related(fg),'expected owned dialog not found'
 opened=fg;snap(label,'dialog',fg);escape_owned()
def click_screen(pt,label,target=None):
 global down
 check();fg=g.GetForegroundWindow();target=target or fg
 assert related(fg) and related(target) and related(g.GetAncestor(g.WindowFromPoint(pt),2))
 a.SetCursorPos(pt);a.mouse_event(k.MOUSEEVENTF_MOVE,1,0,0,0);a.mouse_event(k.MOUSEEVENTF_MOVE,-1,0,0,0)
 check();assert related(g.GetAncestor(g.WindowFromPoint(pt),2))
 a.mouse_event(k.MOUSEEVENTF_LEFTDOWN,0,0);down=True
 try:pass
 finally:a.mouse_event(k.MOUSEEVENTF_LEFTUP,0,0);down=False
 event('ui_click',label=label,screen=pt,foreground=fg);time.sleep(1)
def center(e):
 rc=e['rect_screen'];return ((rc[0]+rc[2])//2,(rc[1]+rc[3])//2)
def wait_dialog():
 until=min(time.time()+4,deadline-5)
 while time.time()<until:
  fg=g.GetForegroundWindow()
  if fg!=h and related(fg):return fg
  time.sleep(.1)
 return h
try:
 assert g.IsWindow(h) and p.GetWindowThreadProcessId(h)[1]==pid
 assert not (R/'command.json').exists()
 d['existing_evidence_hashes']={q.name:hashlib.sha256(q.read_bytes()).hexdigest() for q in list(R.glob('ui-reference-*'))+list(R.glob('user-screen-*')) if q.is_file()}
 event('before_request',owner=dc.current_owner(),pending=dc.pending_request(),target=info(h))
 req=dc.request('Web HWP','user-screen-zoom-2026-10-22','maximize blank dedicated document and measure 100 to 110 percent',120)
 assert req,'foreign request pending'
 rr=dc.pending_request();assert rr['token']==req
 d.update(request_token=req,request_created_at=now(),request_deadline=rr['requested_at']+120);save()
 token=dc.acquire('Web HWP','user-screen-zoom-2026-10-22','zoom-110',timeout=40,request_token=req)
 deadline=min(time.time()+50,d['request_deadline']-10)
 d.update(lock_token=token,acquired_at=now(),input_deadline_epoch=deadline)
 event('acquired',owner=dc.current_owner(),heartbeat=dc.heartbeat(token))
 activate();escape_owned();check()
 g.ShowWindow(h,k.SW_MAXIMIZE);event('maximize_dedicated_window');time.sleep(1.2)
 click(96,48,'Edit label for matched baseline');time.sleep(.8)
 c100=snap('zoom-100')
 d['window_placement']=g.GetWindowPlacement(h)
 es=uia_read(h)['elements'];rc=g.GetWindowRect(h)
 candidates=[e for e in es if e['visible'] and e['name'].strip()=='100%' and e['rect_screen'][1]>rc[3]-45]
 assert len(candidates)==1,'unique current 100 percent status button not found'
 d['status_zoom_control']=candidates[0];save();click_screen(center(candidates[0]),'status zoom 100 percent')
 fg=wait_dialog();opened=fg if fg!=h else None
 ui=uia_read(fg);d['zoom_ui_after_open']={'target':info(fg),'uia':ui};save()
 if fg==h:
  matches=[e for e in ui['elements'] if e['visible'] and e['name'].strip() in ['110%','110 %']]
  assert len(matches)==1,'110 percent popup option not uniquely found; no document key input'
  click_screen(center(matches[0]),'choose 110 percent popup option')
 else:
  assert any(word in g.GetWindowText(fg) for word in ['\ud655\ub300','\ucd95\uc18c','\ubc30\uc728']),'unexpected owned dialog; no typing'
  time.sleep(.8);ui=uia_read(fg);d['zoom_dialog_ready_uia']=ui;save()
  edits=[e for e in ui['elements'] if e['visible'] and e['enabled'] and e['control_type']=='Edit']
  custom=[e for e in ui['elements'] if e['visible'] and '\uc0ac\uc6a9\uc790' in e['name']]
  if custom:click_screen(center(custom[0]),'custom zoom radio',fg)
  ui=uia_read(fg);d['zoom_custom_ready_uia']=ui;save()
  edits=[e for e in ui['elements'] if e['visible'] and e['enabled'] and e['control_type'] in ['Edit','ComboBox'] and e['rect_screen'][1]<512]
  assert len(edits)==1,'zoom editor not unique; no text input'
  edit=edits[0];click_screen(center(edit),'focus zoom percentage field',fg)
  state=gui();d['zoom_edit_focus']=state;save();assert g.GetForegroundWindow()==fg
  chord([k.VK_CONTROL,ord('A')],'select zoom field value')
  for vk in [ord('1'),ord('1'),ord('0')]:chord([vk],'zoom digit')
  buttons=[e for e in ui['elements'] if e['visible'] and e['enabled'] and e['control_type']=='Button' and any(e['name'].startswith(word) for word in ['\ud655\uc778','\uc124\uc815'])]
  assert len(buttons)==1,'zoom confirmation button not unique'
  click_screen(center(buttons[0]),'apply 110 percent',fg)
  until=time.time()+3
  while g.GetForegroundWindow()!=h and time.time()<until:time.sleep(.1)
  assert g.GetForegroundWindow()==h;opened=None
 time.sleep(1);c110=snap('zoom-110')
 actual=[e['name'] for e in c110['uia']['elements'] if e['visible'] and e['name'].strip()=='110%']
 assert actual,'110 percent status text not verified'
 d.update(status='captured_100_110_pending_pixel_measurement',document_text_changed=False,browser_used=False,document_com_used=False)
except Exception as e:d['status']='failed_preserved';d['error']=repr(e);event('failure',error=repr(e))
finally:
 if token:
  if down:a.mouse_event(k.MOUSEEVENTF_LEFTUP,0,0);down=False
  for vk in list(keys):a.keybd_event(vk,0,k.KEYEVENTF_KEYUP,0);keys.discard(vk)
  try:escape_owned();d['cleanup_verified']=True
  except Exception as e:d['cleanup_verified']=False;d['cleanup_error']=repr(e)
  d.update(inputs_finished=True,input_finished_at=now(),down_remaining=down,keys_remaining=list(keys));save()
  assert dc.release(token);d['released_at']=now();event('release_completed')
 if req:
  own=dc.pending_request();assert own and own.get('token')==req
  assert dc.cancel_request(req);d['request_deleted_at']=now();event('own_request_deleted')
 if token:
  until=time.time()+10
  while time.time()<until:
   owner=dc.current_owner();d['owner_after_return']=owner
   if owner and owner.get('owner')=='Astris':d['astris_reacquired_at']=now();break
   time.sleep(.5)
 d['finished']=now();save();print(json.dumps({'status':d['status'],'captures':len(d['captures']),'error':d.get('error'),'report':str(OUT),'owner_after_return':d.get('owner_after_return')},ensure_ascii=True),flush=True)
