"""Offline evidence aggregation only; never sends desktop input."""
import pathlib,json,hashlib,datetime,zipfile,urllib.request
R=pathlib.Path(__file__).resolve().parent
BASE='http://100.105.111.56:18976/'
now=lambda:datetime.datetime.now().astimezone().isoformat()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):(R/name).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
reports=[json.loads(p.read_text(encoding='utf-8')) for p in sorted(R.glob('behavior-reference-*-report.json'))]
scripts={
 'equation-default':'','equation-command-focused':'','equation-a-plus-b':'a+b',
 'equation-before-fraction':'a+b','equation-fraction-template':'a+b {} over {}',
 'equation-numerator-selected':'a+b {} over {}','equation-numerator-one':'a+b {1} over {}',
 'equation-down-to-denominator':'a+b {1} over {}',
 'equation-denominator-selected-settled':'a+b {1} over {}',
 'equation-denominator-two-settled':'a+b {1} over {2}',
 'equation-tab-settled':'a+b {1} over {2}','equation-left-settled':'a+b {1} over {2}',
 'equation-backspace-settled':'a+b {1} over {}',
 'equation-splitter-dragged':'a+b {1} over {}',
 'equation-fraction-dropdown':'a+b {1} over {sqrt {}}',
 'equation-fraction-dropdown-closed':'a+b {1} over {sqrt {}}'}
timing_uncertain=['equation-denominator-two','equation-tab-navigation','equation-left-navigation','equation-backspace']
caps=[];handoffs=[]
for rep in reports:
 if rep.get('acquired_at'):
  seconds=(datetime.datetime.fromisoformat(rep['input_finished_at'])-datetime.datetime.fromisoformat(rep['acquired_at'])).total_seconds()
  assert seconds<60 and rep['released_at']<=rep['request_deleted_at']
  handoffs.append({'report':pathlib.Path(rep.get('collector','')).name,'phase':rep['phase'],'status':rep.get('status'),'error':rep.get('error'),'input_seconds':seconds,**{k:rep.get(k) for k in ['acquired_at','input_finished_at','released_at','request_deleted_at','astris_reacquired_at','owner_after_return','cleanup_verified']}})
 for c in rep.get('captures',[]):
  c=c.copy();short=c['name'].removeprefix('behavior-reference-')
  c['url']=BASE+c['raw'];c['sha256']=sha(R/c['raw'])
  if short in scripts:
   c['script_before_after_source']='Direct transcription of rendered native command pane; normalized whitespace. No COM getter or clipboard read used.'
   c['actual_script_normalized']=scripts[short]
   c['review_status']='verified_actual_native_behavior'
  elif short in timing_uncertain:
   c['review_status']='preserved_timing_unverified';c['review_note']='Immediate screenshot did not prove completed paint; use settled counterpart for reconstruction.'
  else:c['review_status']='captured_image_metadata_reviewed'
  if short.startswith('equation-fraction-dropdown'):
   c['action_label_correction']='Click at window-relative [129,48] hit square-root template primary button, not a fraction dropdown. Image and script prove sqrt insertion. Do not adopt original event label as menu semantics.'
  if 'zoom' in short and c.get('window_rect')==[2,40,1329,1006]:
   c['maximized_verified']=False;c['review_note']='Actual bounds are 1327x966 despite source filename or maximized placement flag.'
  caps.append(c)
coord=pathlib.Path(r'C:\Users\K\.orca\coordination')
owner=json.loads((coord/'desktop-control.owner.json').read_text(encoding='utf-8'))
measurement=json.loads((R/'behavior-reference-zoom-measurement.json').read_text(encoding='utf-8')) if (R/'behavior-reference-zoom-measurement.json').exists() else None
pending=['True maximized matched 100/110 screenshots: restore then maximize collector prepared but not run.','Actual equation dropdown/menu evidence: prior [129,48] click was sqrt template; recorded as such.','Shift+Escape insertion, double-click re-edit and Escape cancel are prepared/pending further authorized shared-control section.']
manifest={'schema':'native-hwp-behavior-reference-v1','status':'partial_awaiting_astris_reacquisition','updated':now(),'output_directory':str(R),'scope':'Dedicated HWP measurement only; no web app edits/browser/deploy/account/model changes. Full native-equivalent UI behavior is not claimed.','stages':{'zoom':'100 to 110 applied and matched 1327x966 evidence measured; true maximized pair pending','equation_default_input':'950x400 default, separate command input and native a+b rendering verified','fraction_navigation':'fraction creation, numerator selection/1, explicit denominator selection/2, Down/Tab/Left/Backspace and splitter drag captured','insert_reedit_cancel':'pending shared-control prerequisite'},'zoom_measurement':measurement,'equation_regions_window_relative':{'title_bar':[0,0,950,32],'toolbar':[1,32,949,98],'preview_initial':[1,99,949,274],'command_input_initial':[1,277,949,375],'splitter_initial_y':275,'splitter_after_drag_y':240,'command_input_after_drag':[1,244,949,375],'fraction_primary_click':[114,48],'sqrt_primary_click':[129,48],'numerator_click':[85,122],'denominator_click':[85,161],'method':'Pixel-observed regions, click coordinates and native HWNDs recorded in captures; individual painted controls have no separate native HWND.'},'script_transition_verified':[{'before':'','action':'type in command pane','after':'a+b'},{'before':'a+b','action':'fraction primary toolbar icon','after':'a+b {} over {}'},{'before':'a+b {} over {}','action':'click numerator and type 1','after':'a+b {1} over {}'},{'before':'a+b {1} over {}','action':'click denominator and type 2; wait 0.9s','after':'a+b {1} over {2}'},{'before':'a+b {1} over {2}','action':'Tab, Left, Backspace','after':'a+b {1} over {}'},{'before':'a+b {1} over {}','action':'click [129,48], actual sqrt button','after':'a+b {1} over {sqrt {}}'}],'captures':caps,'handoffs':handoffs,'shared_control_now':{'observed_at':now(),'owner':owner,'pending_request_exists':(coord/'desktop-control.request').exists(),'new_input_suspended':not bool(owner.get('owner')=='Astris'),'reason':'User explicitly requires observing Astris reacquisition after return. Latest two completed returns remained owner=None and last Astris PID 30616 no longer exists; no Astris process was started/stopped/modified by this collector.'},'remaining':pending,'manual_user_action':'none; Linux supervisor can restore/coordinate Astris or issue a revised control contract; no PC-window check requested','limitations':['Equation script getter unavailable in native custom-painted view; normalized script strings are directly transcribed from screenshots.','Mouse cursor DrawIconEx composite and raw image are separate. Blue/red formula insertion cursor is custom drawn and remains in raw evidence.','Observed sample workflow is incomplete; full equation behavior parity is not claimed.']}
final_zoom=R/'behavior-reference-zoom-measurement-final.json'
half_report=R/'behavior-reference-equation-script-half-clipboard-report.json'
if final_zoom.exists() and half_report.exists():
 z=json.loads(final_zoom.read_text(encoding='utf-8'))
 half=json.loads(half_report.read_text(encoding='utf-8'))
 first=json.loads((R/'behavior-reference-equation-script-clipboard-report.json').read_text(encoding='utf-8'))
 reedit=json.loads((R/'behavior-reference-equation-reedit-finish-report.json').read_text(encoding='utf-8'))
 assert not half.get('error') and not reedit.get('error')
 samples=first['actual_script_samples']+half['actual_script_samples']
 for sample in samples:
  focus=sample.get('focus',{});rc=focus.get('caret_rect')
  if rc:
   valid=0<=rc[0]<=rc[2]<=2000 and 0<=rc[1]<=rc[3]<=1200
   focus['caret_rect_valid']=valid
   if not valid:focus['caret_rect_note']='OS/custom-view caret rectangle is invalid; preserve raw values as evidence, exclude from UI geometry reference. Actual drawn caret remains visible in screenshot.'
 verified={s['sample']:s for s in samples if s['classification']=='actual_CF_UNICODETEXT'}
 assert verified['a+b']['actual_script']=='a+b'
 assert verified['fraction_empty']['actual_script']=='{ } over { }'
 assert verified['fraction_1_2_verified']['actual_script']=='{1} over {2}'
 assert first['clipboard_original_restored'] and half['clipboard_original_restored']
 exact_links={'behavior-reference-equation-script-copy-a-plus-b':'a+b','behavior-reference-equation-script-copy-fraction-empty':'fraction_empty','behavior-reference-equation-script-copy-fraction-one-half':'fraction_1_2','behavior-reference-equation-script-half-filled':'fraction_1_2_verified'}
 for c in caps:
  for key in ['gui','gui_thread']:
   focus=c.get(key,{})
   if focus.get('caret_rect'):
    rc=focus['caret_rect'];focus['caret_rect_valid']=0<=rc[0]<=rc[2]<=2000 and 0<=rc[1]<=rc[3]<=1200
    if not focus['caret_rect_valid']:focus['caret_rect_note']='Invalid OS/custom-view rectangle; do not use as caret geometry. Use native drawn-caret screenshot.'
  c['actual_script']=None
  if c['name'] in exact_links:
   sample=verified[exact_links[c['name']]]
   c['actual_script']=sample['actual_script'];c['actual_script_source']='fresh CF_UNICODETEXT from focused command pane Ctrl+A/C; sequence advanced; no object formats'
   c['clipboard_sample']=sample
  elif c['name'].removeprefix('behavior-reference-') in scripts:
   c['actual_script_source']='Only normalized visual transcription available for this historical state; exact clipboard bytes not measured in that state.'
  else:c['actual_script_source']='Not a script-copy measurement; use linked exact samples for verified syntax.'
  if c['name']=='behavior-reference-equation-script-copy-fraction-one-half':
   c['review_status']='preserved_wrong_slot_click';c['review_note']='Actual CF_UNICODETEXT was 12 {} over {}; not a filled fraction. Corrected [26,122]/[26,161] sample is separate.'
  if c['name']=='behavior-reference-dialog-font-recovered':
   c['review_note']='Historical filename inherited from generic recovery helper. Actual target/title is equation editor reopened after double click, not font dialog.'
 manifest.update(status='requested_native_behavior_reference_verified',zoom_measurement=z,actual_script_samples=samples,exact_script_reference={'a+b':verified['a+b'],'empty_fraction':verified['fraction_empty'],'filled_1_over_2':verified['fraction_1_2_verified']},clipboard_preservation={'both_collection_sections_restored_original':True,'original_user_clipboard_data_logged':False},remaining=[],stages={'zoom':'True maximized matched 100/110 captured; paper left/right/top/width exactly matches supplied reference at 110%.','equation_default_input':'950x400 / HYhwpEQ 11pt / editor 200%; separate native preview/command panes; fresh a+b copy verified.','fraction_navigation':'Toolbar fraction, actual empty { } over { }, filled {1} over {2}, slot clicks, Down/Tab/Left/Backspace and splitter drag measured.','insert_reedit_cancel':'Shift+Escape insertion, actual double-click reopen, superscript/subscript popup and Escape cancel captured; dedicated insertion undone and scratch samples discarded.'},pwa_update_check=json.loads((R/'behavior-reference-pwa-update-report.json').read_text(encoding='utf-8')))
 manifest['equation_regions_window_relative'].update(script_template_menu_arrow=[48,48],script_template_menu_palette=[18,64,181,98],filled_fraction_slot_clicks_empty_equation={'numerator':[26,122],'denominator':[26,161]},double_click_reedit_points_observed=[[386,400],[405,390]],reopen_splitter_y=275)
 manifest['native_escape_semantics']={'changed_equation':'Escape opens native prompt asking whether to insert; choices Insert(Y), Leave(N), Cancel(C). Escape at prompt cancels the prompt and returns to equation editor.','unchanged_reedit':'After template popup dismissed, Escape returned to document with equation unchanged.','source':'behavior-reference-equation-nested-prompt.raw.png and behavior-reference-equation-reedit-finish-report.json'}
 manifest['timing_findings']=['New WPF equation HWND can become foreground before its title/content is populated; first double-click checks failed early but subsequently observed owned windows proved successful reopen. No claim that double-click itself failed.','Readiness and screenshot delay are part of reproduction; immediate historical captures remain marked timing-unverified.']
 manifest['limitations']=['Requested sample workflow and three exact scripts are verified; this does not establish full native equation feature parity.','For other historical expression states only normalized visual transcripts exist; exact CF_UNICODETEXT is not invented.','WPF/custom-painted formula widgets often have no individual HWND/UIA name. Native container HWND, pointer/hotspot, GUI focus/caret and raw custom insertion cursor evidence are provided.','Installed Windows PWA window was absent, so Ctrl+R/SW-cache replacement/document restoration in that window were not tested; no cache or local storage was deleted.','Native visible work area is 1920x1040, while user supplied image was 1918x1031; paper geometry matches exactly, full screenshot cropping differs.']
 audit=R/'behavior-reference-return-audit.json'
 if audit.exists():
  a=json.loads(audit.read_text(encoding='utf-8'));manifest['later_astris_reacquisition_audit']=a
  for hnd in handoffs:
   if hnd['phase'] in a['confirms_later_return_for'] and not hnd['astris_reacquired_at']:hnd['later_astris_reacquisition_verified']=a
 manifest['shared_control_now']['reason']='All UI input finished. Latest successful section released OS lock, removed own request, and observed Astris reacquisition. Earlier delayed return is linked to later audit.'
 manifest['shared_control_now']['new_input_suspended']=True
 manifest['manual_user_action']='none; Linux supervisor can retrieve artifact URLs directly'
 # Prove existing pre-task evidence was not overwritten.
 preserved=json.loads((R/'ui-reference-artifact-index.json').read_text(encoding='utf-8'))
 for item in preserved:
  path=pathlib.Path(item['path']);assert sha(path)==item['sha256'],str(path)
 manifest['previous_ui_reference_evidence_hashes_unchanged']=True
save('behavior-reference-manifest.json',manifest)
files=[p for p in sorted(R.glob('behavior-reference-*')) if p.is_file() and p.suffix!='.zip' and p.name!='behavior-reference-artifact-index.json']
index=[{'path':str(p),'url':BASE+p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]
save('behavior-reference-artifact-index.json',index)
with zipfile.ZipFile(R/'behavior-reference-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[R/'behavior-reference-artifact-index.json']:z.write(p,p.name)
for n in ['behavior-reference-manifest.json','behavior-reference-evidence.zip']:
 with urllib.request.urlopen(BASE+n,timeout=10) as f:assert hashlib.sha256(f.read()).hexdigest()==sha(R/n)
print(json.dumps({'status':manifest['status'],'captures_including_preserved_failed_or_timing_samples':len(caps),'manifest':str(R/'behavior-reference-manifest.json'),'zip_url':BASE+'behavior-reference-evidence.zip','last_owner':owner,'maximum_input_seconds':max(x['input_seconds'] for x in handoffs),'http_hash_verified':True,'remaining':manifest['remaining']},ensure_ascii=False,indent=2))
