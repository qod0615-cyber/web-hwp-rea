"""Pixel measurements of saved native 100/110 screenshots; no UI operations."""
import pathlib,json,statistics,datetime
from PIL import Image
R=pathlib.Path(__file__).resolve().parent
d=json.loads((R/'behavior-reference-zoom-max-report.json').read_text(encoding='utf-8'))
assert not d.get('error') and d.get('astris_reacquired_at')
measurements=[]
for c in d['captures']:
 im=Image.open(R/c['visible_raw']).convert('RGB');runs=[];start=None
 for x in range(im.width):
  white=min(im.getpixel((x,500)))>=250
  if white and start is None:start=x
  if not white and start is not None:runs.append((start,x));start=None
 if start is not None:runs.append((start,im.width))
 left,right=max(runs,key=lambda z:z[1]-z[0]);mid=(left+right)//2
 top_white=next(y for y in range(215,400) if all(min(im.getpixel((x,y)))>=250 for x in [left+10,mid,right-10]))
 ruler=next(e for e in c['native_children'] if e['class']=='HwpRulerWnd' and e['rect_screen'][2]-e['rect_screen'][0]>100)
 ruler_row=ruler['rect_screen'][1]-c['visible_screen_rect'][1]+17
 dark=[x for x in range(left+170,right-110) if max(im.getpixel((x,ruler_row)))<195]
 groups=[]
 for x in dark:
  if not groups or x>groups[-1][-1]+1:groups.append([x])
  else:groups[-1].append(x)
 ticks=[sum(g)/len(g) for g in groups];gaps=[b-a for a,b in zip(ticks,ticks[1:]) if 30<b-a<50]
 assert len(gaps)>8
 status=[e['name'] for e in c['uia']['elements'] if e['visible'] and e['name'].strip() in ['100%','110%']]
 assert len(status)==1
 chrome={e['name']:{'rect_screen':e['rect_screen'],'height':e['rect_screen'][3]-e['rect_screen'][1]} for e in c['uia']['elements'] if e['name'] in ['MenuBar','ToolBox','ToolBar','StatusBar']}
 measurements.append({'capture':c['name'],'raw':c['raw'],'visible_raw':c['visible_raw'],'raw_window_rect_screen':c['window_rect'],'client_rect':c['client_rect'],'client_origin_screen':c['client_origin_screen'],'visible_rect_screen':c['visible_screen_rect'],'visible_image_size':im.size,'dpi':c['dpi'],'actual_zoom_status':status[0],'zoom_percent':int(status[0].rstrip('%')),'physical_paper_width_mm':210.0,'physical_paper_height_mm':297.0,'physical_paper_source':'Actual unchanged F7 page dialog UIA 210.0 x 297.0 mm, previously captured; zoom changes only view.','paper_outer_rect_visible_halfopen':[left-1,top_white-1,right+1,None],'paper_left_screen':c['visible_screen_rect'][0]+left-1,'paper_right_exclusive_screen':c['visible_screen_rect'][0]+right+1,'paper_top_screen':c['visible_screen_rect'][1]+top_white-1,'paper_outer_width_px':right-left+2,'paper_white_width_px':right-left,'ruler_major_tick_x_visible':ticks,'ruler_major_tick_sample_row_visible':ruler_row,'ruler_major_gap_mean_px':statistics.mean(gaps),'ruler_major_gap_median_px':statistics.median(gaps),'chrome':chrome})
assert [m['zoom_percent'] for m in measurements]==[100,110]
assert measurements[0]['raw_window_rect_screen']==measurements[1]['raw_window_rect_screen']
m110=measurements[1]
reference={'paper_left':527,'paper_right_exclusive':1406,'paper_width':879,'paper_top':225,'image_size':[1918,1031]}
delta={'left':m110['paper_left_screen']-527,'right_exclusive':m110['paper_right_exclusive_screen']-1406,'width':m110['paper_outer_width_px']-879,'top':m110['paper_top_screen']-225}
result={'status':'verified_true_maximized_100_110','measured_at':datetime.datetime.now().astimezone().isoformat(),'measurements':measurements,'user_reference':reference,'delta_to_user_reference_px':delta,'paper_matches_user_reference':all(v==0 for v in delta.values()),'ruler_gap_ratio':measurements[1]['ruler_major_gap_mean_px']/measurements[0]['ruler_major_gap_mean_px'],'chrome_heights_unchanged':all(measurements[0]['chrome'][key]['height']==measurements[1]['chrome'][key]['height'] for key in measurements[0]['chrome'] if key in measurements[1]['chrome']),'image_size_difference_note':'This desktop visible work area is 1920x1040; supplied native screenshot is 1918x1031. Paper coordinates compared in screen/work-area origin, not by assuming identical outer screenshot crops.','document_text_changed':False,'astris_return_verified':d['astris_reacquired_at']}
(R/'behavior-reference-zoom-measurement-final.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'status':result['status'],'paper_100':[measurements[0][k] for k in ['paper_left_screen','paper_right_exclusive_screen','paper_top_screen','paper_outer_width_px']],'paper_110':[m110[k] for k in ['paper_left_screen','paper_right_exclusive_screen','paper_top_screen','paper_outer_width_px']],'delta_to_user_reference':delta,'ruler_major_gaps':[m['ruler_major_gap_mean_px'] for m in measurements],'chrome_heights_unchanged':result['chrome_heights_unchanged']},indent=2))
