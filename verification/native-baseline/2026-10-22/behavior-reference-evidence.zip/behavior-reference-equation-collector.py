"""Bounded synchronous UI reference collection; no COM, app edits or resident commands."""
import pathlib,sys,os,time,json,datetime,hashlib,importlib.util,ctypes as C
import ctypes.wintypes as W
import win32gui as g,win32api as a,win32process as p,win32con as k
from PIL import Image,ImageGrab
import win32ui
R=pathlib.Path(__file__).resolve().parent
PHASE=sys.argv[1]
assert PHASE in ['equation-input','equation-template','equation-navigation','equation-navigation-resume','equation-nav-verified','equation-menu','equation-real-menu','equation-prompt','equation-prompt-recovery','equation-insert','equation-reedit','equation-reedit-confirmed','equation-reedit-finish','equation-script-clipboard','equation-script-half-clipboard']
OUT=R/f'behavior-reference-{PHASE}-report.json'
assert not OUT.exists(),'Evidence exists; refusing overwrite'
S=pathlib.Path(r'C:\Users\K\.orca\coordination\desktop_control.py')
assert not os.environ.get('DESKTOP_CONTROL_DIR')
spec=importlib.util.spec_from_file_location('shared_desktop_control',S)
dc=importlib.util.module_from_spec(spec);spec.loader.exec_module(dc)
u=C.windll.user32;u.SetProcessDpiAwarenessContext(C.c_void_p(-4))
h=985892;pid=4032;token=req=None;deadline=0;down=False;keys=set();opened=None
now=lambda:datetime.datetime.now().astimezone().isoformat()
d={'phase':PHASE,'started':now(),'pid':os.getpid(),'target_hwnd':h,'target_pid':pid,'source':str(S),'source_sha256':hashlib.sha256(S.read_bytes()).hexdigest(),'collector':str(pathlib.Path(__file__).resolve()),'collector_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'events':[],'captures':[],'inputs_finished':False,'com_used':False,'resident_commands_sent':False}
def save():
 tmp=OUT.with_suffix('.tmp');tmp.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
 for attempt in range(5):
  try:os.replace(tmp,OUT);return
  except PermissionError:
   if attempt==4:raise
   time.sleep(.05)
def event(kind,**kw):d['events'].append({'kind':kind,'time':now(),'epoch':time.time(),**kw});save()
def related(w):
 try:
  if not w or p.GetWindowThreadProcessId(w)[1]!=pid:return False
  root=g.GetAncestor(w,2)
  for _ in range(8):
   if root==h:return True
   root=g.GetWindow(root,k.GW_OWNER)
   if not root:break
  return False
 except:return False
def check(cleanup=False):
 assert token and dc.holds(token) and dc.current_owner().get('token')==token,'OS lock ownership lost'
 assert time.time()<(d['request_deadline']-5 if cleanup else deadline),'input deadline'
 assert related(g.GetForegroundWindow()),'foreign foreground; no input'
def info(w):
 rc=g.GetWindowRect(w);o=g.ClientToScreen(h,(0,0));wr=g.GetWindowRect(h)
 return {'hwnd':w,'pid':p.GetWindowThreadProcessId(w)[1],'class':g.GetClassName(w),'name':g.GetWindowText(w),'id':g.GetDlgCtrlID(w),'rect_screen':rc,'rect_client_main':[rc[0]-o[0],rc[1]-o[1],rc[2]-o[0],rc[3]-o[1]],'rect_window_main':[rc[0]-wr[0],rc[1]-wr[1],rc[2]-wr[0],rc[3]-wr[1]],'visible':bool(g.IsWindowVisible(w)),'enabled':bool(g.IsWindowEnabled(w)),'parent':g.GetParent(w),'owner':g.GetWindow(g.GetAncestor(w,2),k.GW_OWNER),'root_owner':g.GetAncestor(w,3)}
def uia_read(w):
 out=[];until=min(time.time()+4,deadline-3)
 try:
  from pywinauto import Desktop
  queue=[(Desktop(backend='uia').window(handle=w).wrapper_object().element_info,0)]
  while queue and len(out)<450 and time.time()<until:
   e,depth=queue.pop(0);rc=e.rectangle
   out.append({'name':e.name,'class':e.class_name,'automation_id':e.automation_id,'control_type':e.control_type,'hwnd':e.handle,'rect_screen':[rc.left,rc.top,rc.right,rc.bottom],'visible':e.visible,'enabled':e.enabled})
   if depth<7:queue.extend((child,depth+1) for child in e.children())
  return {'elements':out,'truncated':bool(queue),'method':'UIA read-only; native dialog editing COM not used'}
 except Exception as e:return {'elements':out,'error':repr(e)}
def children(w):
 out=[]
 def cb(c,_):
  try:out.append(info(c))
  except Exception as e:out.append({'hwnd':c,'error':repr(e)})
 g.EnumChildWindows(w,cb,None);return out
class GTI(C.Structure):
 _fields_=[('size',W.DWORD),('flags',W.DWORD),('active',W.HWND),('focus',W.HWND),('capture',W.HWND),('menu',W.HWND),('move',W.HWND),('caret',W.HWND),('rect',W.RECT)]
def gui():
 t=GTI();t.size=C.sizeof(t);thread=p.GetWindowThreadProcessId(g.GetForegroundWindow())[0]
 assert u.GetGUIThreadInfo(thread,C.byref(t))
 return {'flags':t.flags,'active':t.active,'focus':t.focus,'menu_owner':t.menu,'capture':t.capture,'caret_hwnd':t.caret,'caret_rect':[t.rect.left,t.rect.top,t.rect.right,t.rect.bottom]}
def snap(label,kind='editor',target=None):
 check();target=target or h;assert related(target)
 accessibility=uia_read(target)
 if kind=='dialog':
  time.sleep(.9);check()
  rc=g.GetWindowRect(target);pt=(rc[0]+min(220,(rc[2]-rc[0])//2),rc[1]+14)
  assert g.GetAncestor(g.WindowFromPoint(pt),2)==target,'rendered dialog title not hit; no mouse input'
  a.SetCursorPos(pt);a.mouse_event(k.MOUSEEVENTF_MOVE,1,0,0,0);a.mouse_event(k.MOUSEEVENTF_MOVE,-1,0,0,0)
  event('move_to_owned_dialog_title',screen=pt,hwnd=target)
 if kind=='dialog':time.sleep(.9)
 check()
 name='behavior-reference-'+label;assert not (R/(name+'.raw.png')).exists()
 fg=g.GetForegroundWindow();rect=g.GetWindowRect(h);tr=g.GetWindowRect(target)
 shot=ImageGrab.grab(bbox=rect,all_screens=True);shot.save(R/(name+'.raw.png'))
 if target!=h:ImageGrab.grab(bbox=tr,all_screens=True).save(R/(name+'.dialog.png'))
 samples=[]
 for x in [rect[0]+20,(rect[0]+rect[2])//2,rect[2]-20]:
  for y in [rect[1]+15,rect[1]+100,(rect[1]+rect[3])//2,rect[3]-15]:
   w=g.WindowFromPoint((x,y));samples.append({'screen':[x,y],'hwnd':w,'related':related(g.GetAncestor(w,2))})
 assert related(g.GetForegroundWindow()) and all(v['related'] for v in samples),'occlusion or foreground changed'
 c={'name':name,'kind':kind,'time':now(),'raw':name+'.raw.png','dialog_raw':name+'.dialog.png' if target!=h else None,'window':info(h),'window_rect':rect,'client_rect':g.GetClientRect(h),'client_origin_screen':g.ClientToScreen(h,(0,0)),'dpi':u.GetDpiForWindow(h),'units':'physical pixels; rectangles half-open','zoom':{'text':'100%','source':'status bar visual review required','ribbon_160_percent':'character width ratio; not document zoom'},'foreground':info(fg),'target':info(target),'gui_thread':gui(),'native_children':children(target),'main_native_children':children(h) if target!=h else None,'occlusion_samples':samples,'input_event_count':len(d['events']),'status':'pending_visual_review'}
 c['uia']=accessibility
 d['captures'].append(c);save();print(json.dumps({'capture':str(R/c['raw']),'report':str(OUT)},ensure_ascii=True),flush=True)
 return c
def click(x,y,label):
 global down
 check();assert g.GetForegroundWindow()==h,'main editor not foreground'
 pt=g.ClientToScreen(h,(x,y));hit=g.WindowFromPoint(pt);assert related(g.GetAncestor(hit,2))
 a.SetCursorPos(pt);a.mouse_event(k.MOUSEEVENTF_MOVE,1,0,0,0);a.mouse_event(k.MOUSEEVENTF_MOVE,-1,0,0,0)
 check();assert related(g.GetAncestor(g.WindowFromPoint(pt),2))
 a.mouse_event(k.MOUSEEVENTF_LEFTDOWN,0,0);down=True
 try:pass
 finally:a.mouse_event(k.MOUSEEVENTF_LEFTUP,0,0);down=False
 wr=g.GetWindowRect(h);event('click',label=label,client=[x,y],screen=pt,window_relative=[pt[0]-wr[0],pt[1]-wr[1]],hit=info(hit));time.sleep(.8)
def chord(vks,label,cleanup=False):
 check(cleanup)
 try:
  for vk in vks:a.keybd_event(vk,0,0,0);keys.add(vk)
 finally:
  for vk in reversed(vks):a.keybd_event(vk,0,k.KEYEVENTF_KEYUP,0);keys.discard(vk)
 event('key_chord',keys=vks,label=label,foreground=g.GetForegroundWindow());time.sleep(.3)
def escape_owned():
 global opened
 check(True);fg=g.GetForegroundWindow();state=gui()
 assert related(fg)
 if fg!=h:assert opened==fg,'unexpected dialog; no Escape'
 elif state['flags']&28:assert state['menu_owner'] and related(state['menu_owner']),'unproven menu owner'
 elif state['capture']==h and state['focus']==h:event('own_wpf_menu_capture_verified',state=state)
 else:return
 chord([k.VK_ESCAPE],'close own dialog/menu',True)
 until=time.time()+3
 while time.time()<until and (g.GetForegroundWindow()!=h or gui()['flags']&28):time.sleep(.1)
 assert g.GetForegroundWindow()==h and not(gui()['flags']&28) and not gui()['capture'],'own dialog/menu did not close'
 opened=None
def resize(w,ht):
 check();assert g.GetForegroundWindow()==h
 g.SetWindowPos(h,k.HWND_TOP,2,40,w,ht,k.SWP_SHOWWINDOW);event('resize',width=w,height=ht);time.sleep(.3)
 assert tuple(g.GetWindowRect(h)[2+i]-g.GetWindowRect(h)[i] for i in [0,1])==(w,ht)
def activate():
 assert dc.holds(token) and time.time()<deadline
 existing=[]
 def cb(w,_):
  if w!=h and g.IsWindowVisible(w) and related(w):existing.append(w)
 g.EnumWindows(cb,None)
 if existing:
  assert len(existing)==1 and not g.IsWindowEnabled(h),'unexpected pre-existing owned windows'
  global opened
  opened=existing[0]
  g.SetWindowPos(opened,k.HWND_TOP,0,0,0,0,k.SWP_NOMOVE|k.SWP_NOSIZE|k.SWP_SHOWWINDOW)
  u.SetForegroundWindow(opened);time.sleep(.3)
  if g.GetForegroundWindow()!=opened:
   rc=g.GetWindowRect(opened);pt=((rc[0]+rc[2])//2,rc[1]+14)
   assert g.GetAncestor(g.WindowFromPoint(pt),2)==opened and related(opened) and dc.holds(token) and time.time()<deadline
   a.SetCursorPos(pt);a.mouse_event(k.MOUSEEVENTF_LEFTDOWN,0,0)
   try:pass
   finally:a.mouse_event(k.MOUSEEVENTF_LEFTUP,0,0)
   event('activate_owned_dialog_title',hwnd=opened,screen=pt);time.sleep(.4)
  snap('dialog-font-recovered','dialog',opened);escape_owned()
 g.SetWindowPos(h,k.HWND_TOP,2,40,1327,966,k.SWP_SHOWWINDOW);u.SetForegroundWindow(h);time.sleep(.15)
 if g.GetForegroundWindow()!=h:
  rc=g.GetWindowRect(h);pt=((rc[0]+rc[2])//2,rc[1]+12)
  assert g.GetAncestor(g.WindowFromPoint(pt),2)==h
  a.SetCursorPos(pt);a.mouse_event(k.MOUSEEVENTF_LEFTDOWN,0,0)
  try:pass
  finally:a.mouse_event(k.MOUSEEVENTF_LEFTUP,0,0)
  event('activate_title_click',screen=pt);time.sleep(.2)
 assert g.GetForegroundWindow()==h
def dialog(label,seq):
 global opened
 check();assert g.GetForegroundWindow()==h and not(gui()['flags']&28)
 for keys_,text in seq:chord(keys_,text)
 until=min(time.time()+4,deadline-3)
 while time.time()<until:
  fg=g.GetForegroundWindow()
  if fg!=h and related(fg):break
  time.sleep(.1)
 fg=g.GetForegroundWindow()
 assert fg!=h and related(fg),'expected owned dialog not found'
 opened=fg;snap(label,'dialog',fg);escape_owned()
class CI(C.Structure): _fields_=[('size',W.DWORD),('flags',W.DWORD),('cursor',W.HANDLE),('pos',W.POINT)]
class BIH(C.Structure): _fields_=[('size',W.DWORD),('width',W.LONG),('height',W.LONG),('planes',W.WORD),('bits',W.WORD),('compression',W.DWORD),('image_size',W.DWORD),('xppm',W.LONG),('yppm',W.LONG),('used',W.DWORD),('important',W.DWORD)]
gd=C.windll.gdi32
gd.CreateDIBSection.restype=W.HBITMAP; gd.CreateDIBSection.argtypes=[W.HDC,C.c_void_p,W.UINT,C.POINTER(C.c_void_p),W.HANDLE,W.DWORD]
gd.SelectObject.restype=W.HANDLE; gd.SelectObject.argtypes=[W.HDC,W.HANDLE]
gd.DeleteObject.argtypes=[W.HANDLE]
def draw_image(base,cur,xy):
    dc0=g.GetDC(0); screen=win32ui.CreateDCFromHandle(dc0); mem=screen.CreateCompatibleDC(); w,h=base.size
    header=BIH(C.sizeof(BIH),w,-h,1,32,0,w*h*4,0,0,0,0); bits=C.c_void_p(); bitmap=gd.CreateDIBSection(mem.GetSafeHdc(),C.byref(header),0,C.byref(bits),None,0)
    if not bitmap: raise RuntimeError('CreateDIBSection failed')
    old=gd.SelectObject(mem.GetSafeHdc(),bitmap)
    try:
        C.memmove(bits,base.convert('RGB').tobytes('raw','BGRX'),w*h*4)
        g.DrawIconEx(mem.GetSafeHdc(),xy[0],xy[1],cur,0,0,0,None,3)
        return Image.frombytes('RGB',(w,h),C.string_at(bits,w*h*4),'raw','BGRX')
    finally:
        gd.SelectObject(mem.GetSafeHdc(),old); gd.DeleteObject(bitmap); mem.DeleteDC(); g.ReleaseDC(0,dc0)

eq=None
topmost_restore={}
clipboard_backup=None
statefile=R/'behavior-reference-equation-session.json'
def clip_open():
 import win32clipboard as cb
 for n in range(8):
  try:cb.OpenClipboard();return cb
  except Exception:
   if n==7:raise
   time.sleep(.05)
def clip_formats(cb):
 formats=[];f=0
 while True:
  f=cb.EnumClipboardFormats(f)
  if not f:break
  try:name=cb.GetClipboardFormatName(f) if f>=0xC000 else {1:'CF_TEXT',13:'CF_UNICODETEXT',16:'CF_LOCALE',7:'CF_OEMTEXT'}.get(f,str(f))
  except:name=str(f)
  formats.append({'id':f,'name':name})
 return formats
def clip_stash():
 global clipboard_backup
 cb=clip_open()
 try:
  formats=clip_formats(cb);backup=[]
  for f in formats:
   value=cb.GetClipboardData(f['id'])
   assert isinstance(value,(str,bytes)),'original clipboard contains unsupported handle/object format; do not modify'
   backup.append((f['id'],value))
  clipboard_backup=backup;d['clipboard_original_formats']=formats;d['clipboard_original_data_logged']=False
 finally:cb.CloseClipboard()
 event('clipboard_original_stashed_in_memory',format_count=len(clipboard_backup))
def copy_equation_script(label):
 check();assert eq and g.GetForegroundWindow()==eq
 click_eq(25,300,'focus actual command pane for script copy '+label)
 before=u.GetClipboardSequenceNumber()
 chord([k.VK_CONTROL,ord('A')],'select command text only '+label)
 chord([k.VK_CONTROL,ord('C')],'copy command script '+label)
 until=time.time()+1.5
 while time.time()<until and u.GetClipboardSequenceNumber()==before:time.sleep(.1)
 after=u.GetClipboardSequenceNumber();cb=clip_open()
 try:
  formats=clip_formats(cb)
  object_copy=any(any(t in f['name'].lower() for t in ['embed source','object descriptor','link source','hwp object','hwpctrl']) for f in formats)
  value=cb.GetClipboardData(13) if after!=before and not object_copy and cb.IsClipboardFormatAvailable(13) else None
 finally:cb.CloseClipboard()
 entry={'sample':label,'time':now(),'clipboard_sequence_before':before,'clipboard_sequence_after':after,'formats':formats,'copied_object_format_detected':object_copy,'actual_script':value,'classification':'object_formats_only_no_script_inference' if object_copy else 'actual_CF_UNICODETEXT' if value is not None else 'no_fresh_unicode_text','focus':gui(),'command_pane_click_window_relative':[25,300]}
 d.setdefault('actual_script_samples',[]).append(entry);event('native_script_copy_recorded',sample=label,classification=entry['classification']);return entry
def promote_own(w):
 assert related(w) and dc.holds(token) and time.time()<deadline
 if w not in topmost_restore:topmost_restore[w]=bool(g.GetWindowLong(w,k.GWL_EXSTYLE)&k.WS_EX_TOPMOST)
 g.SetWindowPos(w,k.HWND_TOPMOST,0,0,0,0,k.SWP_NOMOVE|k.SWP_NOSIZE|k.SWP_SHOWWINDOW)
 event('temporary_own_topmost_for_activation',hwnd=w,original_topmost=topmost_restore[w])
def click_eq(x,y,label):
 global down
 check();assert g.GetForegroundWindow()==eq and related(eq)
 rc=g.GetWindowRect(eq);pt=(rc[0]+x,rc[1]+y);hit=g.WindowFromPoint(pt)
 assert g.GetAncestor(hit,2)==eq,'point outside own equation window'
 a.SetCursorPos(pt);a.mouse_event(k.MOUSEEVENTF_MOVE,1,0,0,0);a.mouse_event(k.MOUSEEVENTF_MOVE,-1,0,0,0)
 check();assert g.GetAncestor(g.WindowFromPoint(pt),2)==eq
 a.mouse_event(k.MOUSEEVENTF_LEFTDOWN,0,0);down=True
 try:pass
 finally:a.mouse_event(k.MOUSEEVENTF_LEFTUP,0,0);down=False
 event('equation_click',window_relative=[x,y],screen=pt,label=label,hit=info(hit));time.sleep(.4)
def ascii_text(text):
 check();assert g.GetForegroundWindow()==eq
 for ch in text:
  scan=a.VkKeyScan(ch);assert scan!=-1
  mods=[]
  if scan&0x100:mods.append(k.VK_SHIFT)
  if scan&0x200:mods.append(k.VK_CONTROL)
  if scan&0x400:mods.append(k.VK_MENU)
  chord(mods+[scan&255],'equation character '+repr(ch))
 event('equation_typed',literal=text)
def eqsnap(label,expected=None):
 check();assert eq and g.GetForegroundWindow()==eq
 time.sleep(.9);check()
 name='behavior-reference-'+label;rect=g.GetWindowRect(eq);assert not (R/(name+'.raw.png')).exists()
 raw=ImageGrab.grab(bbox=rect,all_screens=True);raw.save(R/(name+'.raw.png'))
 ci=CI();ci.size=C.sizeof(CI);assert u.GetCursorInfo(C.byref(ci));cur={'handle':ci.cursor,'visible':bool(ci.flags&1),'screen':[ci.pos.x,ci.pos.y]}
 if ci.cursor:
  isicon,hx,hy,mask,color=g.GetIconInfo(ci.cursor)
  try:
   bi=win32ui.CreateBitmapFromHandle(color or mask).GetInfo();size=[bi['bmWidth'],bi['bmHeight'] if color else bi['bmHeight']//2]
   cur.update(hotspot=[hx,hy],size=size)
   for bg in ['white','black']:draw_image(Image.new('RGB',size,bg),ci.cursor,(0,0)).save(R/(name+'.cursor-'+bg+'.png'))
   draw_image(raw,ci.cursor,(ci.pos.x-rect[0]-hx,ci.pos.y-rect[1]-hy)).save(R/(name+'.composite.png'))
  finally:
   for obj in [mask,color]:
    if obj:g.DeleteObject(obj)
 samples=[]
 for dx,dy in [(20,15),(rect[2]-rect[0]-20,15),(30,120),(30,310),(rect[2]-rect[0]-20,rect[3]-rect[1]-20)]:
  pt=(rect[0]+dx,rect[1]+dy);hit=g.WindowFromPoint(pt);samples.append({'screen':pt,'hwnd':hit,'root':g.GetAncestor(hit,2)})
 assert all(related(s['root']) for s in samples),'equation window covered by unrelated window'
 entry={'name':name,'raw':name+'.raw.png','time':now(),'window':info(eq),'dpi':u.GetDpiForWindow(eq),'gui':gui(),'cursor':cur,'native_children':children(eq),'input_event_count':len(d['events']),'expected_script':expected,'actual_script':'pending screenshot transcription; native custom view has no exposed script getter','occlusion_samples':samples,'status':'pending_visual_behavior_review'}
 d['captures'].append(entry);save();print(json.dumps({'capture':str(R/entry['raw']),'report':str(OUT)}),flush=True)
 return entry
def start_equation():
 global eq,opened
 click(500,400,'focus dedicated blank document')
 for v,text in [([k.VK_CONTROL,ord('N')],'Ctrl+N'),([ord('M')],'M')]:chord(v,text)
 until=min(time.time()+5,deadline-5)
 while time.time()<until:
  fg=g.GetForegroundWindow()
  if fg!=h and related(fg) and 'Eq' in g.GetClassName(fg):break
  if fg!=h and related(fg) and g.GetWindowText(fg):break
  time.sleep(.1)
 eq=g.GetForegroundWindow();assert eq!=h and related(eq)
 assert g.GetClassName(eq)=='HwpEqnWnd' or '\uc218\uc2dd' in g.GetWindowText(eq),'unexpected dialog'
 opened=eq;time.sleep(1);event('equation_opened',window=info(eq),placement=g.GetWindowPlacement(eq))
def activate_existing_equation():
 global eq,opened
 st=json.loads(statefile.read_text(encoding='utf-8'));eq=st['equation_hwnd']
 assert g.IsWindow(eq) and related(eq),'previous equation window vanished'
 opened=eq;promote_own(eq);u.SetForegroundWindow(eq);time.sleep(.2)
 if g.GetForegroundWindow()!=eq:
  rc=g.GetWindowRect(eq);pt=((rc[0]+rc[2])//2,rc[1]+14)
  assert g.GetAncestor(g.WindowFromPoint(pt),2)==eq and dc.holds(token) and time.time()<deadline
  a.SetCursorPos(pt);a.mouse_event(k.MOUSEEVENTF_LEFTDOWN,0,0)
  try:pass
  finally:a.mouse_event(k.MOUSEEVENTF_LEFTUP,0,0)
  time.sleep(.2)
 assert g.GetForegroundWindow()==eq
def finish_reedit():
  global eq,opened
  opened=eq;promote_own(eq);time.sleep(.8);eqsnap('equation-doubleclick-reedited')
  click_eq(48,48,'A1 script-template dropdown arrow');eqsnap('equation-script-menu-observed')
  top=[]
  def cb(w,_):
   if w not in [h,eq] and g.IsWindowVisible(w) and related(w):top.append(info(w))
  g.EnumWindows(cb,None);d['script_menu_owned_windows']=top;save()
  if top or gui()['capture']:
   chord([k.VK_ESCAPE],'dismiss own script-template palette');time.sleep(.6)
   assert g.GetForegroundWindow()==eq and g.IsWindowEnabled(eq)
   eqsnap('equation-script-menu-dismissed')
  chord([k.VK_ESCAPE],'Escape cancel re-edit');time.sleep(1)
  fg=g.GetForegroundWindow()
  if fg!=h:
   assert related(fg) and g.GetWindow(fg,k.GW_OWNER)==eq,'unexpected cancel prompt ownership'
   opened=fg;promote_own(fg);time.sleep(.5);ui=uia_read(fg)
   d['reedit_cancel_prompt_uia']=ui;d['reedit_cancel_prompt']=info(fg)
   ImageGrab.grab(bbox=g.GetWindowRect(fg),all_screens=True).save(R/'behavior-reference-equation-reedit-cancel-prompt.raw.png');save()
   leave=[e for e in ui['elements'] if e['visible'] and e['control_type']=='Button' and e['name'].startswith('\ub098\uac00\uae30')]
   assert len(leave)==1,'discard button not unique'
   rr=leave[0]['rect_screen'];pp=((rr[0]+rr[2])//2,(rr[1]+rr[3])//2)
   check();assert g.GetAncestor(g.WindowFromPoint(pp),2)==fg
   a.SetCursorPos(pp);a.mouse_event(k.MOUSEEVENTF_LEFTDOWN,0,0)
   try:pass
   finally:a.mouse_event(k.MOUSEEVENTF_LEFTUP,0,0)
   event('discard_reedit_via_native_prompt',button=leave[0]);time.sleep(1)
  assert g.GetForegroundWindow()==h,'re-edit cancel did not return to document'
  opened=None;eq=None;time.sleep(.7);snap('equation-reedit-cancelled-document')
  chord([k.VK_CONTROL,ord('Z')],'undo only dedicated test equation insertion to restore blank fixture');time.sleep(1)
  snap('equation-fixture-restored-blank')

try:
 assert g.IsWindow(h) and p.GetWindowThreadProcessId(h)[1]==pid
 assert not (R/'command.json').exists()
 event('before_request',owner=dc.current_owner(),target=info(h))
 req=dc.request('Web HWP','behavior-reference-2026-10-22',PHASE,120);assert req,'foreign request pending'
 rr=dc.pending_request();d.update(request_token=req,request_created_at=now(),request_deadline=rr['requested_at']+120);save()
 token=dc.acquire('Web HWP','behavior-reference-2026-10-22',PHASE,timeout=40,request_token=req)
 deadline=min(time.time()+50,d['request_deadline']-10);d.update(acquired_at=now(),lock_token=token,input_deadline_epoch=deadline);event('acquired',owner=dc.current_owner(),heartbeat=dc.heartbeat(token))
 if PHASE in ['equation-script-clipboard','equation-script-half-clipboard']:
  clip_stash();activate();escape_owned();start_equation();promote_own(eq)
  if PHASE=='equation-script-clipboard':
   click_eq(25,300,'focus blank command pane');ascii_text('a+b');eqsnap('equation-script-copy-a-plus-b')
   copy_equation_script('a+b')
   chord([k.VK_DELETE],'clear selected own command script')
   click_eq(114,48,'fraction primary icon in empty equation');eqsnap('equation-script-copy-fraction-empty')
   copy_equation_script('fraction_empty')
   click_eq(17,122,'select empty numerator');ascii_text('1')
   click_eq(17,161,'select empty denominator');ascii_text('2');eqsnap('equation-script-copy-fraction-one-half')
   copy_equation_script('fraction_1_2')
  else:
   click_eq(114,48,'fraction primary icon in empty equation');eqsnap('equation-script-half-empty')
   click_eq(26,122,'inside numerator placeholder verified from prior raw');ascii_text('1')
   click_eq(26,161,'inside denominator placeholder verified from prior raw');ascii_text('2');eqsnap('equation-script-half-filled')
   copy_equation_script('fraction_1_2_verified')
  chord([k.VK_RIGHT],'collapse own command selection')
  chord([k.VK_ESCAPE],'close own scratch equation editor');time.sleep(1.5)
  fg=g.GetForegroundWindow()
  if fg==eq:
   chord([k.VK_MENU,k.VK_F4],'close own scratch equation window');time.sleep(1)
   fg=g.GetForegroundWindow()
  if fg!=h:
   assert related(fg) and g.GetWindow(fg,k.GW_OWNER)==eq,'unexpected scratch cancel prompt'
   opened=fg;promote_own(fg);time.sleep(.5);ui=uia_read(fg)
   d['script_copy_close_prompt_uia']=ui;save()
   leave=[e for e in ui['elements'] if e['visible'] and e['control_type']=='Button' and e['name'].startswith('\ub098\uac00\uae30')];assert len(leave)==1
   rr=leave[0]['rect_screen'];pt=((rr[0]+rr[2])//2,(rr[1]+rr[3])//2);check();assert g.GetAncestor(g.WindowFromPoint(pt),2)==fg
   a.SetCursorPos(pt);a.mouse_event(k.MOUSEEVENTF_LEFTDOWN,0,0)
   try:pass
   finally:a.mouse_event(k.MOUSEEVENTF_LEFTUP,0,0)
   event('discard_scratch_equation',button=leave[0]);time.sleep(1)
  assert g.GetForegroundWindow()==h
  opened=None;eq=None;snap('equation-script-samples-discarded-blank' if PHASE=='equation-script-clipboard' else 'equation-script-half-discarded-blank')
 elif PHASE in ['equation-prompt','equation-prompt-recovery']:
  st=json.loads(statefile.read_text(encoding='utf-8'));eq=st['equation_hwnd']
  matches=[]
  def cb(w,_):
   if g.IsWindowVisible(w) and related(w) and g.GetWindow(w,k.GW_OWNER)==eq and g.IsWindowEnabled(w):matches.append(w)
  g.EnumWindows(cb,None);assert len(matches)==1,'nested equation prompt not unique'
  prompt=matches[0];opened=prompt
  promote_own(eq);promote_own(prompt);u.SetForegroundWindow(prompt);time.sleep(.3)
  if g.GetForegroundWindow()!=prompt:
   pr=g.GetWindowRect(prompt);pt=((pr[0]+pr[2])//2,pr[1]+14)
   assert g.GetAncestor(g.WindowFromPoint(pt),2)==prompt and dc.holds(token)
   a.SetCursorPos(pt);a.mouse_event(k.MOUSEEVENTF_LEFTDOWN,0,0)
   try:pass
   finally:a.mouse_event(k.MOUSEEVENTF_LEFTUP,0,0)
   time.sleep(.3)
  check();assert g.GetForegroundWindow()==prompt
  d['nested_prompt']=info(prompt);d['nested_prompt_uia']=uia_read(prompt);save();time.sleep(.8)
  name='behavior-reference-equation-nested-prompt.raw.png';assert not (R/name).exists()
  ImageGrab.grab(bbox=g.GetWindowRect(prompt),all_screens=True).save(R/name)
  d['captures'].append({'name':'behavior-reference-equation-nested-prompt','raw':name,'time':now(),'window':info(prompt),'uia':d['nested_prompt_uia'],'status':'pending_visual_review'});save()
  chord([k.VK_ESCAPE],'cancel own nested equation prompt');time.sleep(.8)
  assert not g.IsWindowVisible(prompt) and g.GetForegroundWindow()==eq and g.IsWindowEnabled(eq),'nested prompt did not cancel back to equation editor'
  opened=eq;eqsnap('equation-after-nested-prompt-cancel')
 elif PHASE=='equation-input':
  activate();escape_owned();start_equation();eqsnap('equation-default','')
  rc=g.GetWindowRect(eq);d['default_equation_size']=[rc[2]-rc[0],rc[3]-rc[1]]
  click_eq(25,300,'command input region');eqsnap('equation-command-focused','')
  ascii_text('a+b');time.sleep(.5);eqsnap('equation-a-plus-b','a+b')
 elif PHASE=='equation-template':
  activate_existing_equation();eqsnap('equation-before-fraction')
  click_eq(114,48,'fraction template primary icon');eqsnap('equation-fraction-template')
 elif PHASE in ['equation-navigation','equation-navigation-resume']:
  activate_existing_equation()
  if PHASE=='equation-navigation':
   click_eq(85,122,'select empty numerator placeholder');eqsnap('equation-numerator-selected')
   ascii_text('1');eqsnap('equation-numerator-one')
  chord([k.VK_DOWN],'Down numerator to denominator');eqsnap('equation-down-to-denominator')
  ascii_text('2');eqsnap('equation-denominator-two')
  chord([k.VK_TAB],'Tab leave current fraction slot');eqsnap('equation-tab-navigation')
  chord([k.VK_LEFT],'Left navigation');eqsnap('equation-left-navigation')
  chord([k.VK_BACK],'Backspace current equation element');eqsnap('equation-backspace')
  # A bounded splitter drag changes only the dedicated equation layout.
  check();rc=g.GetWindowRect(eq);start=(rc[0]+475,rc[1]+275);end=(start[0],start[1]-35)
  assert g.GetAncestor(g.WindowFromPoint(start),2)==eq
  a.SetCursorPos(start);a.mouse_event(k.MOUSEEVENTF_LEFTDOWN,0,0);down=True
  try:
   for step in range(1,6):
    check();a.SetCursorPos((start[0],start[1]-7*step));a.mouse_event(k.MOUSEEVENTF_MOVE,0,0,0,0);time.sleep(.05)
  finally:a.mouse_event(k.MOUSEEVENTF_LEFTUP,0,0);down=False
  event('splitter_drag',start_screen=start,end_screen=end,expected_delta_y=-35);eqsnap('equation-splitter-dragged')
 elif PHASE=='equation-nav-verified':
  activate_existing_equation()
  click_eq(85,161,'explicit denominator selection');eqsnap('equation-denominator-selected-settled')
  ascii_text('2');eqsnap('equation-denominator-two-settled')
  chord([k.VK_TAB],'Tab navigation settled');eqsnap('equation-tab-settled')
  chord([k.VK_LEFT],'Left navigation settled');eqsnap('equation-left-settled')
  chord([k.VK_BACK],'Backspace settled');eqsnap('equation-backspace-settled')
 elif PHASE=='equation-menu':
  activate_existing_equation();click_eq(129,48,'fraction dropdown arrow');eqsnap('equation-fraction-dropdown')
  assert g.GetForegroundWindow()==eq and related(eq)
  chord([k.VK_ESCAPE],'close own fraction dropdown');eqsnap('equation-fraction-dropdown-closed')
 elif PHASE=='equation-real-menu':
  activate_existing_equation();click_eq(48,48,'superscript/subscript template dropdown arrow');eqsnap('equation-script-template-menu')
  d['menu_uia']=uia_read(eq)
  top=[]
  def cb(w,_):
   if w not in [h,eq] and g.IsWindowVisible(w) and related(w):top.append(info(w))
  g.EnumWindows(cb,None);d['menu_owned_top_windows']=top;save()
  assert g.GetForegroundWindow()==eq and related(eq)
  chord([k.VK_ESCAPE],'close own template menu');eqsnap('equation-script-template-menu-closed')
 elif PHASE=='equation-insert':
  activate_existing_equation();eqsnap('equation-before-insert')
  chord([k.VK_SHIFT,k.VK_ESCAPE],'Shift+Escape insert equation')
  until=time.time()+4
  while time.time()<until and g.GetForegroundWindow()!=h:time.sleep(.1)
  assert g.GetForegroundWindow()==h,'Shift+Escape did not return to own document'
  opened=None;time.sleep(1);snap('equation-inserted-document')
 elif PHASE=='equation-reedit-finish':
  matches=[]
  def cb(w,_):
   if g.IsWindowVisible(w) and related(w) and g.GetWindow(w,k.GW_OWNER)==h and '\uc218\uc2dd \ud3b8\uc9d1\uae30' in g.GetWindowText(w):matches.append(w)
  g.EnumWindows(cb,None);assert len(matches)==1,'owned re-edit equation window not unique'
  eq=matches[0];event('adopt_delayed_reedit_window',window=info(eq),causal_report='behavior-reference-equation-reedit-confirmed-report.json')
  statefile.write_text(json.dumps({'equation_hwnd':eq,'owner_hwnd':h,'phase':PHASE,'time':now()},indent=2),encoding='utf-8')
  promote_own(h);activate_existing_equation();finish_reedit()
 elif PHASE in ['equation-reedit','equation-reedit-confirmed']:
  activate();promote_own(h);escape_owned();check()
  if PHASE=='equation-reedit-confirmed':snap('equation-reedit-before-confirmed-click')
  relative=(405,390) if PHASE=='equation-reedit-confirmed' else (386,400)
  pt=g.ClientToScreen(h,relative);assert g.GetAncestor(g.WindowFromPoint(pt),2)==h
  a.SetCursorPos(pt)
  a.mouse_event(k.MOUSEEVENTF_MOVE,1,0,0,0);a.mouse_event(k.MOUSEEVENTF_MOVE,-1,0,0,0);time.sleep(.2)
  for n in range(2):
   check();assert g.GetAncestor(g.WindowFromPoint(pt),2)==h
   a.mouse_event(k.MOUSEEVENTF_LEFTDOWN,0,0)
   try:pass
   finally:a.mouse_event(k.MOUSEEVENTF_LEFTUP,0,0)
   time.sleep(.08)
  event('double_click_inserted_equation',screen=pt,client=list(relative),evidence='behavior-reference-equation-inserted-document.raw.png')
  until=time.time()+5
  while time.time()<until:
   fg=g.GetForegroundWindow()
   if fg!=h and related(fg):break
   time.sleep(.1)
  eq=g.GetForegroundWindow();assert eq!=h and related(eq) and '\uc218\uc2dd' in g.GetWindowText(eq),'double click did not reopen equation editor'
  finish_reedit()
 else:raise RuntimeError('phase implementation pending observed evidence')
 statefile.write_text(json.dumps({'equation_hwnd':eq,'owner_hwnd':h,'phase':PHASE,'time':now()},indent=2),encoding='utf-8')
 d['status']='captured_pending_review'
except Exception as e:d['status']='failed_preserved';d['error']=repr(e);event('failure',error=repr(e))
finally:
 if token:
  if down:a.mouse_event(k.MOUSEEVENTF_LEFTUP,0,0);down=False
  for vk in list(keys):a.keybd_event(vk,0,k.KEYEVENTF_KEYUP,0);keys.discard(vk)
  if clipboard_backup is not None:
   cb=clip_open()
   try:
    cb.EmptyClipboard()
    for f,value in clipboard_backup:cb.SetClipboardData(f,value)
    d['clipboard_original_restored']=all(cb.GetClipboardData(f)==value for f,value in clipboard_backup)
    assert d['clipboard_original_restored'],'original clipboard restore verification failed'
   finally:cb.CloseClipboard()
   d['clipboard_restored_at']=now();save()
  # Keep only own ordinary equation editor open between measurement sections; never an active popup/menu or drag.
  if eq and g.IsWindow(eq) and g.GetForegroundWindow()==eq:
   d['equation_left_open_idle']=True;d['cleanup_verified']=not bool(gui()['capture']) and not bool(gui()['flags']&28)
  else:
   try:escape_owned();d['cleanup_verified']=True
   except Exception as e:d['cleanup_verified']=False;d['cleanup_error']=repr(e)
  d.update(inputs_finished=True,input_finished_at=now(),down_remaining=down,keys_remaining=list(keys));save()
  for w,was_topmost in topmost_restore.items():
   if g.IsWindow(w) and not was_topmost:g.SetWindowPos(w,k.HWND_NOTOPMOST,0,0,0,0,k.SWP_NOMOVE|k.SWP_NOSIZE|k.SWP_NOACTIVATE)
  d['own_topmost_restored_at']=now();save()
  assert dc.release(token);d['released_at']=now();event('release_completed')
 if req:
  own=dc.pending_request();assert own and own.get('token')==req
  assert dc.cancel_request(req);d['request_deleted_at']=now();event('own_request_deleted')
 if token:
  until=time.time()+10
  while time.time()<until:
   owner=dc.current_owner();d['owner_after_return']=owner
   if owner and owner.get('owner')=='Astris':d['astris_reacquired_at']=now();break
   time.sleep(.5)
 d['finished']=now();save();print(json.dumps({'status':d['status'],'captures':len(d['captures']),'error':d.get('error'),'report':str(OUT),'owner_after_return':d.get('owner_after_return')}),flush=True)
